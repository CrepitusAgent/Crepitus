import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const FINNHUB_API_KEY = "d9dl6h1r01qui7p2lqrgd9dl6h1r01qui7p2lqs0";
const FINNHUB_QUOTE_URL = "https://finnhub.io/api/v1/quote";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { data: feeds, error: feedsError } = await supabase
      .from("oracle_feeds")
      .select("*");

    if (feedsError) throw feedsError;
    if (!feeds || feeds.length === 0) throw new Error("No oracle feeds found");

    const updatedFeeds = [];
    const historyRecords = [];

    for (const feed of feeds) {
      const quoteUrl = `${FINNHUB_QUOTE_URL}?symbol=${encodeURIComponent(feed.symbol)}&token=${FINNHUB_API_KEY}`;
      const quoteRes = await fetch(quoteUrl);
      if (!quoteRes.ok) {
        throw new Error(`Finnhub quote failed for ${feed.symbol}: ${quoteRes.status}`);
      }
      const quote: { c: number; d: number; dp: number; h: number; l: number; o: number; pc: number } = await quoteRes.json();

      const currentPrice = quote.c;
      if (currentPrice === 0 || currentPrice === null || currentPrice === undefined) {
        throw new Error(`Finnhub returned no price for ${feed.symbol}`);
      }

      const roundedPrice = Math.round(currentPrice * 100) / 100;

      await supabase
        .from("oracle_feeds")
        .update({
          prev_price_usd: feed.price_usd,
          price_usd: roundedPrice,
          source: "finnhub",
          last_updated: new Date().toISOString(),
        })
        .eq("id", feed.id);

      if (feed.route_id) {
        await supabase
          .from("route_reserves")
          .update({
            oracle_price_usd: roundedPrice,
            current_nav: roundedPrice,
            last_oracle_update: new Date().toISOString(),
          })
          .eq("id", feed.route_id);
      }

      historyRecords.push({
        feed_id: feed.id,
        symbol: feed.symbol,
        price_usd: roundedPrice,
        prev_price_usd: feed.price_usd,
      });

      updatedFeeds.push({
        symbol: feed.symbol,
        price: roundedPrice,
        delta: Math.round((currentPrice - feed.price_usd) * 100) / 100,
        change_pct: quote.dp,
        day_high: quote.h,
        day_low: quote.l,
        day_open: quote.o,
        prev_close: quote.pc,
      });
    }

    if (historyRecords.length > 0) {
      await supabase.from("oracle_price_history").insert(historyRecords);
    }

    await supabase.from("agent_activity").insert({
      event_type: "oracle",
      message: `Oracle update (Finnhub): ${updatedFeeds.map((f) => `${f.symbol} $${f.price}`).join(", ")}`,
      payload: { feeds: updatedFeeds, timestamp: new Date().toISOString(), source: "finnhub" },
    });

    return new Response(
      JSON.stringify({ success: true, feeds: updatedFeeds, source: "finnhub" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
