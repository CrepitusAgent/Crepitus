import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, X-Client-Info, Apikey",
};

function generateTxHash(): string {
  const chars = "0123456789abcdef";
  let hash = "0x";
  for (let i = 0; i < 64; i++) {
    hash += chars[Math.floor(Math.random() * 16)];
  }
  return hash;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { action, wallet_address, asset_symbol, crep_amount, shares_to_burn } =
      await req.json();

    if (!wallet_address || !asset_symbol) {
      return new Response(
        JSON.stringify({ error: "wallet_address and asset_symbol required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: feed, error: feedError } = await supabase
      .from("oracle_feeds")
      .select("*, route_reserves:route_id(*)")
      .eq("symbol", asset_symbol)
      .maybeSingle();

    if (feedError) throw feedError;
    if (!feed) throw new Error(`No oracle feed found for ${asset_symbol}`);

    const route = feed.route_reserves;
    if (!route) throw new Error(`No route reserve found for ${asset_symbol}`);

    const txHash = generateTxHash();

    if (action === "mint") {
      if (!crep_amount || crep_amount <= 0) {
        return new Response(
          JSON.stringify({ error: "crep_amount must be positive" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const navPerShare = feed.price_usd;
      const shares = crep_amount / navPerShare;
      const newTotalCrepLocked = route.total_crep_locked + crep_amount;
      const newTotalShares = route.total_shares_outstanding + shares;
      const newReserveRatio = (newTotalCrepLocked / (newTotalShares * navPerShare)) * 100;

      if (newReserveRatio < 130) {
        return new Response(
          JSON.stringify({
            error: "Mint rejected: reserve ratio would drop below 130%",
            current_ratio: route.reserve_ratio_pct,
            projected_ratio: Math.round(newReserveRatio),
          }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      await supabase.from("synthetic_positions").insert({
        wallet_address: wallet_address.toLowerCase(),
        asset_symbol,
        asset_name: feed.name,
        shares_minted: Math.round(shares * 10000) / 10000,
        nav_per_share: navPerShare,
        crep_locked: crep_amount,
        reserve_ratio: Math.round(newReserveRatio),
        status: "open",
      });

      await supabase
        .from("route_reserves")
        .update({
          total_crep_locked: Math.round(newTotalCrepLocked),
          total_shares_outstanding: Math.round(newTotalShares * 10000) / 10000,
          reserve_ratio_pct: Math.round(newReserveRatio),
        })
        .eq("id", route.id);

      await supabase.from("mint_burn_log").insert({
        wallet_address: wallet_address.toLowerCase(),
        action: "mint",
        asset_symbol,
        shares: Math.round(shares * 10000) / 10000,
        crep_amount,
        nav_at_execution: navPerShare,
        tx_hash: txHash,
      });

      await supabase.from("agent_activity").insert({
        event_type: "mint",
        message: `Minted ${shares.toFixed(2)} s${asset_symbol} for ${crep_amount.toLocaleString()} $CREP at NAV $${navPerShare}`,
        payload: { wallet: wallet_address.slice(0, 8), symbol: asset_symbol, shares, crep_amount },
      });

      return new Response(
        JSON.stringify({
          success: true,
          action: "mint",
          shares_minted: Math.round(shares * 10000) / 10000,
          nav_per_share: navPerShare,
          crep_locked: crep_amount,
          reserve_ratio: Math.round(newReserveRatio),
          tx_hash: txHash,
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } else if (action === "redeem") {
      if (!shares_to_burn || shares_to_burn <= 0) {
        return new Response(
          JSON.stringify({ error: "shares_to_burn must be positive" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const navPerShare = feed.price_usd;
      const crepRelease = shares_to_burn * navPerShare;
      const newTotalCrepLocked = Math.max(0, route.total_crep_locked - crepRelease);
      const newTotalShares = Math.max(0, route.total_shares_outstanding - shares_to_burn);
      const newReserveRatio = newTotalShares > 0
        ? (newTotalCrepLocked / (newTotalShares * navPerShare)) * 100
        : 999;

      await supabase
        .from("route_reserves")
        .update({
          total_crep_locked: Math.round(newTotalCrepLocked),
          total_shares_outstanding: Math.round(newTotalShares * 10000) / 10000,
          reserve_ratio_pct: Math.round(newReserveRatio),
        })
        .eq("id", route.id);

      await supabase.from("mint_burn_log").insert({
        wallet_address: wallet_address.toLowerCase(),
        action: "redeem",
        asset_symbol,
        shares: shares_to_burn,
        crep_amount: Math.round(crepRelease),
        nav_at_execution: navPerShare,
        tx_hash: txHash,
      });

      await supabase.from("agent_activity").insert({
        event_type: "mint",
        message: `Redeemed ${shares_to_burn.toFixed(2)} s${asset_symbol} for ${Math.round(crepRelease).toLocaleString()} $CREP at NAV $${navPerShare}`,
        payload: { wallet: wallet_address.slice(0, 8), symbol: asset_symbol, shares: shares_to_burn, crep_release: crepRelease },
      });

      return new Response(
        JSON.stringify({
          success: true,
          action: "redeem",
          shares_burned: shares_to_burn,
          crep_released: Math.round(crepRelease),
          nav_per_share: navPerShare,
          tx_hash: txHash,
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } else {
      return new Response(
        JSON.stringify({ error: "action must be 'mint' or 'redeem'" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
