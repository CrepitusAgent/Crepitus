import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Small venue metric fluctuation (tick-level)
    const { data: venues } = await supabase.from("venues").select("id, apy, liquidity_usd").order("rank");
    if (venues) {
      for (const v of venues) {
        const apyNudge = (Math.random() - 0.5) * 0.15;
        const liqNudge = (Math.random() - 0.5) * 2000000;
        await supabase
          .from("venues")
          .update({
            apy: Math.max(1, Math.round((v.apy + apyNudge) * 100) / 100),
            liquidity_usd: Math.max(10000000, Math.round(v.liquidity_usd + liqNudge)),
            updated_at: new Date().toISOString(),
          })
          .eq("id", v.id);
      }
    }

    // Generate a monitoring event
    const monitorMessages = [
      "Venue APY check - all within threshold",
      "Liquidity depth scan - no anomalies detected",
      "Risk matrix updated - correlation stable",
      "Slippage check - all venues within bounds",
      "XRPL bridge status: operational",
      "Robinhood relay heartbeat: healthy",
      "Vault utilization metrics refreshed",
      "Cross-venue correlation matrix recalculated",
    ];

    const message = monitorMessages[Math.floor(Math.random() * monitorMessages.length)];

    await supabase.from("agent_activity").insert({
      event_type: "monitoring",
      message,
      payload: { tick: Date.now() },
    });

    // Update AUM slightly
    const { data: state } = await supabase.from("agent_state").select("total_aum").eq("id", 1).maybeSingle();
    if (state) {
      const aumDelta = (Math.random() - 0.45) * 500000;
      await supabase
        .from("agent_state")
        .update({ total_aum: Math.max(100000000, Math.round(state.total_aum + aumDelta)) })
        .eq("id", 1);
    }

    return new Response(
      JSON.stringify({ success: true, message }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
