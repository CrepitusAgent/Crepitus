import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const SYSTEM_PROMPT = `You are Crepitus Agent, an intelligent financial analyst embedded in the Crepitus protocol dashboard. Crepitus is an on-chain synthetic equity protocol where users lock $CREP as collateral into route reserves to mint synthetic stock positions backed by live oracle price feeds.

Your role:
- Answer questions about the protocol, market conditions, and user portfolios
- Explain metrics and risk indicators in plain language
- Provide analysis based on the data provided in context

Rules:
- NEVER invent data. Only reference data provided in context.
- Never provide financial advice. Say "this data suggests" not "you should."
- Keep responses concise (2-4 sentences for simple questions).
- Reference specific numbers from the context when available.

Key concepts:
- Route Reserves: Pools of locked $CREP collateral backing synthetic equities
- Reserve Ratio: Collateralization level (150%+ healthy, 130% minimum)
- Composite Score: Weighted venue ranking (APY 30%, Liquidity 20%, Safety 25%, Decorrelation 15%, Low-Slippage 10%)
- Oracle Feeds: Live price data updated every 2 minutes
- Rebalancing: Agent routes capital to highest-scoring venue`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const openaiKey = Deno.env.get("OPENAI_API_KEY");
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { message, history, context } = await req.json();
    if (!message) {
      return new Response(JSON.stringify({ error: "message is required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Gather live data
    const [
      { data: agentState },
      { data: venues },
      { data: feeds },
      { data: reserves },
      { data: recentActivity },
    ] = await Promise.all([
      supabase.from("agent_state").select("*").eq("id", 1).maybeSingle(),
      supabase.from("venues").select("*").order("rank").limit(6),
      supabase.from("oracle_feeds").select("*"),
      supabase.from("route_reserves").select("*"),
      supabase.from("agent_activity").select("*").order("created_at", { ascending: false }).limit(5),
    ]);

    const protocolContext = buildContext(agentState, venues, feeds, reserves, recentActivity);

    // If no OpenAI key, use rule-based fallback
    if (!openaiKey) {
      const fallback = generateFallback(message, protocolContext);
      return new Response(JSON.stringify(fallback), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Call OpenAI
    const messages = [
      { role: "system", content: SYSTEM_PROMPT + "\n\nCurrent Protocol Data:\n" + protocolContext },
      ...(history || []).slice(-8).map((h: any) => ({ role: h.role, content: h.content })),
      { role: "user", content: message },
    ];

    const openaiResp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${openaiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: "gpt-4o-mini", messages, max_tokens: 500, temperature: 0.7 }),
    });

    if (!openaiResp.ok) {
      const fallback = generateFallback(message, protocolContext);
      return new Response(JSON.stringify(fallback), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const completion = await openaiResp.json();
    const reply = completion.choices?.[0]?.message?.content || "Unable to generate response.";

    return new Response(JSON.stringify({
      reply,
      sources: ["Agent State", "Oracle Feeds", "Route Reserves", "Venue Scores"],
      suggestions: getSuggestions(context?.activeTab),
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

function buildContext(agentState: any, venues: any[], feeds: any[], reserves: any[], activity: any[]): string {
  const parts: string[] = [];

  if (agentState) {
    parts.push(`Agent: Best Venue=${agentState.current_best_venue}, AUM=$${(agentState.total_aum/1e6).toFixed(1)}M, Rebalances=${agentState.rebalance_count}, Yield=$${(agentState.total_yield_routed/1000).toFixed(1)}K`);
  }
  if (venues?.length) {
    parts.push("Venues: " + venues.map((v,i) => `#${i+1} ${v.name} APY=${v.apy}% Risk=${v.risk_score} Score=${v.composite_score}`).join(" | "));
  }
  if (feeds?.length) {
    parts.push("Feeds: " + feeds.map(f => {
      const chg = f.prev_price_usd > 0 ? ((f.price_usd - f.prev_price_usd)/f.prev_price_usd*100).toFixed(2) : "0";
      return `${f.symbol}=$${f.price_usd.toFixed(2)}(${Number(chg)>=0?"+":""}${chg}%)`;
    }).join(" | "));
  }
  if (reserves?.length) {
    const total = reserves.reduce((s,r) => s + r.total_crep_locked, 0);
    const avgRatio = reserves.reduce((s,r) => s + r.reserve_ratio_pct, 0) / reserves.length;
    parts.push(`Reserves: Total CREP=${(total/1e6).toFixed(2)}M, Avg Ratio=${avgRatio.toFixed(0)}%, Routes=${reserves.length}`);
  }
  if (activity?.length) {
    parts.push("Recent: " + activity.map(a => `[${a.event_type}] ${a.message}`).join(" | "));
  }
  return parts.join("\n");
}

function generateFallback(message: string, context: string): { reply: string; sources: string[]; suggestions: string[] } {
  const lower = message.toLowerCase();
  if (lower.includes("health") || lower.includes("status")) {
    return { reply: `Protocol Status:\n${context.split("\n").slice(0,3).join("\n")}\n\nAll systems operational with regular oracle updates and active routing.`, sources: ["Agent State", "Oracle Feeds"], suggestions: ["What is the reserve ratio?", "Show venue rankings", "Any recent rebalances?"] };
  }
  if (lower.includes("risk") || lower.includes("reserve")) {
    const reserveLine = context.split("\n").find(l => l.startsWith("Reserves:")) || "No reserve data";
    return { reply: `${reserveLine}\n\nReserve ratios above 150% indicate healthy collateralization. Below 130% restricts new minting.`, sources: ["Route Reserves"], suggestions: ["Which routes are at risk?", "Explain liquidation", "Show oracle freshness"] };
  }
  if (lower.includes("venue") || lower.includes("score") || lower.includes("rank")) {
    const venueLine = context.split("\n").find(l => l.startsWith("Venues:")) || "No venue data";
    return { reply: `${venueLine}\n\nVenues scored by: APY (30%), Liquidity (20%), Safety (25%), Decorrelation (15%), Low Slippage (10%).`, sources: ["Venue Scores"], suggestions: ["Compare APYs", "What is decorrelation?", "Show risk distribution"] };
  }
  return {
    reply: `I can help with protocol analytics. Current data:\n${context.split("\n").slice(0,2).join("\n")}\n\nAsk about market conditions, risk metrics, venues, or oracle feeds.`,
    sources: ["System"],
    suggestions: ["What is protocol health?", "Show venue rankings", "Explain reserve ratios"],
  };
}

function getSuggestions(tab?: string): string[] {
  const map: Record<string, string[]> = {
    overview: ["What changed recently?", "Protocol health summary", "Explain yield velocity"],
    venues: ["Compare top venues", "Which is safest?", "Explain composite scoring"],
    risk: ["Main protocol risks?", "Reserve adequacy?", "Concentration risk?"],
  };
  return map[tab || "overview"] || map.overview;
}
