import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch current venues
    const { data: venues, error: venuesError } = await supabase
      .from("venues")
      .select("*")
      .order("rank", { ascending: true });

    if (venuesError) throw venuesError;
    if (!venues || venues.length === 0) throw new Error("No venues found");

    // Log scoring start
    await supabase.from("agent_activity").insert({
      event_type: "scoring",
      message: `Scoring cycle initiated - evaluating ${venues.length} venues`,
      payload: { venues_count: venues.length },
    });

    // Re-score each venue with randomized fluctuation
    const updatedVenues = venues.map((v) => {
      const apyDelta = (Math.random() - 0.4) * 1.5;
      const newApy = Math.max(1, v.apy + apyDelta);
      const liqDelta = (Math.random() - 0.5) * 20000000;
      const newLiquidity = Math.max(10000000, v.liquidity_usd + liqDelta);
      const riskDelta = (Math.random() - 0.5) * 8;
      const newRisk = Math.max(5, Math.min(80, v.risk_score + riskDelta));
      const corrDelta = (Math.random() - 0.5) * 0.06;
      const newCorrelation = Math.max(0.02, Math.min(0.9, v.correlation + corrDelta));
      const slipDelta = (Math.random() - 0.5) * 3;
      const newSlippage = Math.max(1, Math.min(30, v.slippage_bps + slipDelta));

      // Composite: weighted sum (APY 30%, liquidity 20%, safety 25%, decorrelation 15%, low-slip 10%)
      const apyScore = Math.min(newApy / 15, 1) * 30;
      const liqScore = Math.min(newLiquidity / 400000000, 1) * 20;
      const safetyScore = ((100 - newRisk) / 100) * 25;
      const corrScore = ((1 - newCorrelation) / 1) * 15;
      const slipScore = (Math.max(0, 20 - newSlippage) / 20) * 10;
      const composite = apyScore + liqScore + safetyScore + corrScore + slipScore;

      return {
        ...v,
        apy: Math.round(newApy * 100) / 100,
        liquidity_usd: Math.round(newLiquidity),
        risk_score: Math.round(newRisk * 10) / 10,
        correlation: Math.round(newCorrelation * 1000) / 1000,
        slippage_bps: Math.round(newSlippage * 10) / 10,
        composite_score: Math.round(composite * 10) / 10,
      };
    });

    // Sort by composite score and assign ranks
    updatedVenues.sort((a, b) => b.composite_score - a.composite_score);
    updatedVenues.forEach((v, i) => { v.rank = i + 1; });

    // Update venues in DB
    for (const v of updatedVenues) {
      await supabase
        .from("venues")
        .update({
          apy: v.apy,
          liquidity_usd: v.liquidity_usd,
          risk_score: v.risk_score,
          correlation: v.correlation,
          slippage_bps: v.slippage_bps,
          composite_score: v.composite_score,
          rank: v.rank,
          updated_at: new Date().toISOString(),
        })
        .eq("id", v.id);
    }

    const winner = updatedVenues[0];
    const previousBest = venues[0];

    // Log scoring result
    await supabase.from("agent_activity").insert({
      event_type: "scoring",
      message: `${winner.name} leads with composite ${winner.composite_score}`,
      payload: { venue: winner.name, score: winner.composite_score, apy: winner.apy },
    });

    // Check if rebalance needed (winner changed or significant score delta)
    const needsRebalance = winner.name !== previousBest.name ||
      Math.abs(winner.composite_score - previousBest.composite_score) > 3;

    if (needsRebalance) {
      const amount = Math.round(1000000 + Math.random() * 5000000);
      const reason = winner.name !== previousBest.name
        ? `Venue leader changed: ${previousBest.name} -> ${winner.name}, composite delta ${(winner.composite_score - previousBest.composite_score).toFixed(1)}`
        : `Score improvement +${(winner.composite_score - previousBest.composite_score).toFixed(1)} at ${winner.name}`;

      // Generate fake tx hash
      const chars = "0123456789abcdef";
      let txHash = "0x";
      for (let i = 0; i < 64; i++) {
        txHash += chars[Math.floor(Math.random() * 16)];
      }

      // Log routing
      await supabase.from("agent_activity").insert({
        event_type: "routing",
        message: `Routing $${(amount / 1000000).toFixed(1)}M from ${previousBest.name} to ${winner.name}`,
        payload: { amount, from: previousBest.name, to: winner.name },
      });

      // Log bridging
      await supabase.from("agent_activity").insert({
        event_type: "bridging",
        message: "Bridging assets via XRPL to Robinhood relay",
        payload: { bridge: "XRPL", status: "in_progress" },
      });

      // Insert rebalance record
      await supabase.from("rebalances").insert({
        from_venue: previousBest.name,
        to_venue: winner.name,
        amount_usd: amount,
        reason,
        tx_hash: txHash,
        status: "completed",
      });

      // Log settled
      await supabase.from("agent_activity").insert({
        event_type: "settled",
        message: `Rebalance settled - tx confirmed`,
        payload: { tx_hash: txHash.slice(0, 12) + "..." },
      });

      // Update agent state
      const { data: currentState } = await supabase
        .from("agent_state")
        .select("*")
        .eq("id", 1)
        .maybeSingle();

      const newCount = (currentState?.rebalance_count || 0) + 1;
      const newYieldRouted = (currentState?.total_yield_routed || 0) + amount * (winner.apy / 100 / 1460);

      await supabase
        .from("agent_state")
        .update({
          current_best_venue: winner.name,
          last_rebalance_at: new Date().toISOString(),
          next_rebalance_at: new Date(Date.now() + 6 * 3600 * 1000).toISOString(),
          rebalance_count: newCount,
          total_yield_routed: Math.round(newYieldRouted),
        })
        .eq("id", 1);
    } else {
      // Just update next rebalance time
      await supabase
        .from("agent_state")
        .update({
          current_best_venue: winner.name,
          next_rebalance_at: new Date(Date.now() + 6 * 3600 * 1000).toISOString(),
        })
        .eq("id", 1);
    }

    return new Response(
      JSON.stringify({ success: true, winner: winner.name, rebalanced: needsRebalance }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
