/*
# Enable pg_cron and http extensions, schedule agent functions

1. Extensions
  - `pg_cron` - PostgreSQL job scheduler for recurring tasks
  - `http` - HTTP client for calling edge functions from within the DB

2. Scheduled Jobs
  - `crepitus-agent-rebalance` - Runs every 6 hours, triggers the full scoring + rebalance cycle
  - `crepitus-tick` - Runs every 2 minutes, nudges venue metrics and streams monitoring events

3. Notes
  - Both jobs call the edge functions via HTTP POST
  - The edge functions use the service role key for authenticated DB access
  - pg_cron jobs run as the database superuser
*/

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS http;

-- Schedule the main rebalance agent every 6 hours
SELECT cron.schedule(
  'crepitus-agent-rebalance',
  '0 */6 * * *',
  $$
  SELECT http_post(
    current_setting('app.settings.supabase_url') || '/functions/v1/crepitus-agent',
    '{}',
    'application/json'
  );
  $$
);

-- Schedule the tick function every 2 minutes
SELECT cron.schedule(
  'crepitus-tick',
  '*/2 * * * *',
  $$
  SELECT http_post(
    current_setting('app.settings.supabase_url') || '/functions/v1/crepitus-tick',
    '{}',
    'application/json'
  );
  $$
);
