/*
# Schedule oracle price refresh from Finnhub

Adds a pg_cron job that calls the crepitus-oracle edge function
every 2 minutes so live Finnhub quotes stream into oracle_feeds
and route_reserves.
*/

SELECT cron.schedule(
  'crepitus-oracle',
  '*/2 * * * *',
  $$
  SELECT extensions.http_post(
    current_setting('app.settings.supabase_url') || '/functions/v1/crepitus-oracle',
    '{}',
    'application/json'
  );
  $$
);
