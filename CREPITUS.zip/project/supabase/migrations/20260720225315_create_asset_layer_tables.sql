/*
# Create Asset Layer Tables for Synthetic Equity Positions

This migration adds the collateral/synthetic equity layer to Crepitus,
enabling CREP token holders to mint synthetic stock positions backed by
locked CREP reserves within route treasuries.

1. New Tables

  - `route_reserves` - Tracks CREP collateral locked per route/venue
    - `id` (uuid, primary key)
    - `venue_id` (uuid, FK to venues) - the route backing this reserve
    - `total_crep_locked` (numeric) - total CREP tokens locked as collateral
    - `total_shares_outstanding` (numeric) - total synthetic shares minted against this reserve
    - `current_nav` (numeric) - net asset value per share in USD
    - `oracle_price_usd` (numeric) - latest oracle equity mark
    - `reserve_ratio_pct` (numeric) - collateralization ratio (e.g. 150 = 150%)
    - `last_oracle_update` (timestamptz) - when oracle last streamed price
    - `status` (text) - active/paused/liquidating

  - `oracle_feeds` - Live price feeds for each equity ticker
    - `id` (uuid, primary key)
    - `symbol` (text) - stock ticker (e.g. AAPL)
    - `name` (text) - full company name
    - `price_usd` (numeric) - current oracle price
    - `prev_price_usd` (numeric) - previous price for delta calc
    - `source` (text) - oracle source identifier
    - `route_id` (uuid, FK to route_reserves) - which route backs this equity
    - `last_updated` (timestamptz)

  - `synthetic_positions` - User-minted synthetic equity positions
    - `id` (uuid, primary key)
    - `wallet_address` (text) - holder wallet
    - `asset_symbol` (text) - equity ticker
    - `asset_name` (text) - full name
    - `shares_minted` (numeric) - number of synthetic shares held
    - `nav_per_share` (numeric) - NAV at time of mint
    - `crep_locked` (numeric) - CREP locked for this position
    - `reserve_ratio` (numeric) - ratio at time of mint
    - `minted_at` (timestamptz) - when position was opened
    - `status` (text) - open/redeemed/liquidated

  - `mint_burn_log` - Immutable audit log of all mint/redeem events
    - `id` (uuid, primary key)
    - `wallet_address` (text)
    - `action` (text) - mint or redeem
    - `asset_symbol` (text)
    - `shares` (numeric)
    - `crep_amount` (numeric)
    - `nav_at_execution` (numeric)
    - `tx_hash` (text)
    - `created_at` (timestamptz)

2. Security
  - RLS enabled on all tables
  - Public SELECT for all (dashboard is public)
  - INSERT/UPDATE/DELETE open to anon + authenticated (edge functions write via service role)

3. Indexes
  - oracle_feeds: symbol, route_id
  - synthetic_positions: wallet_address, asset_symbol
  - mint_burn_log: wallet_address, created_at DESC
  - route_reserves: venue_id
*/

-- Route Reserves table
CREATE TABLE IF NOT EXISTS route_reserves (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id uuid REFERENCES venues(id) ON DELETE SET NULL,
  total_crep_locked numeric NOT NULL DEFAULT 0,
  total_shares_outstanding numeric NOT NULL DEFAULT 0,
  current_nav numeric NOT NULL DEFAULT 0,
  oracle_price_usd numeric NOT NULL DEFAULT 0,
  reserve_ratio_pct numeric NOT NULL DEFAULT 150,
  last_oracle_update timestamptz DEFAULT now(),
  status text NOT NULL DEFAULT 'active'
);

ALTER TABLE route_reserves ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_route_reserves" ON route_reserves;
CREATE POLICY "anon_select_route_reserves" ON route_reserves FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_route_reserves" ON route_reserves;
CREATE POLICY "anon_insert_route_reserves" ON route_reserves FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_route_reserves" ON route_reserves;
CREATE POLICY "anon_update_route_reserves" ON route_reserves FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_route_reserves" ON route_reserves;
CREATE POLICY "anon_delete_route_reserves" ON route_reserves FOR DELETE
  TO anon, authenticated USING (true);

-- Oracle Feeds table
CREATE TABLE IF NOT EXISTS oracle_feeds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  symbol text NOT NULL,
  name text NOT NULL,
  price_usd numeric NOT NULL DEFAULT 0,
  prev_price_usd numeric NOT NULL DEFAULT 0,
  source text NOT NULL DEFAULT 'route-oracle-aggregator',
  route_id uuid REFERENCES route_reserves(id) ON DELETE SET NULL,
  last_updated timestamptz DEFAULT now()
);

ALTER TABLE oracle_feeds ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_oracle_feeds" ON oracle_feeds;
CREATE POLICY "anon_select_oracle_feeds" ON oracle_feeds FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_oracle_feeds" ON oracle_feeds;
CREATE POLICY "anon_insert_oracle_feeds" ON oracle_feeds FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_oracle_feeds" ON oracle_feeds;
CREATE POLICY "anon_update_oracle_feeds" ON oracle_feeds FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_oracle_feeds" ON oracle_feeds;
CREATE POLICY "anon_delete_oracle_feeds" ON oracle_feeds FOR DELETE
  TO anon, authenticated USING (true);

-- Synthetic Positions table
CREATE TABLE IF NOT EXISTS synthetic_positions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_address text NOT NULL,
  asset_symbol text NOT NULL,
  asset_name text NOT NULL,
  shares_minted numeric NOT NULL DEFAULT 0,
  nav_per_share numeric NOT NULL DEFAULT 0,
  crep_locked numeric NOT NULL DEFAULT 0,
  reserve_ratio numeric NOT NULL DEFAULT 150,
  minted_at timestamptz DEFAULT now(),
  status text NOT NULL DEFAULT 'open'
);

ALTER TABLE synthetic_positions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_synthetic_positions" ON synthetic_positions;
CREATE POLICY "anon_select_synthetic_positions" ON synthetic_positions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_synthetic_positions" ON synthetic_positions;
CREATE POLICY "anon_insert_synthetic_positions" ON synthetic_positions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_synthetic_positions" ON synthetic_positions;
CREATE POLICY "anon_update_synthetic_positions" ON synthetic_positions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_synthetic_positions" ON synthetic_positions;
CREATE POLICY "anon_delete_synthetic_positions" ON synthetic_positions FOR DELETE
  TO anon, authenticated USING (true);

-- Mint Burn Log table
CREATE TABLE IF NOT EXISTS mint_burn_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_address text NOT NULL,
  action text NOT NULL,
  asset_symbol text NOT NULL,
  shares numeric NOT NULL DEFAULT 0,
  crep_amount numeric NOT NULL DEFAULT 0,
  nav_at_execution numeric NOT NULL DEFAULT 0,
  tx_hash text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE mint_burn_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_mint_burn_log" ON mint_burn_log;
CREATE POLICY "anon_select_mint_burn_log" ON mint_burn_log FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_mint_burn_log" ON mint_burn_log;
CREATE POLICY "anon_insert_mint_burn_log" ON mint_burn_log FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_mint_burn_log" ON mint_burn_log;
CREATE POLICY "anon_update_mint_burn_log" ON mint_burn_log FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_mint_burn_log" ON mint_burn_log;
CREATE POLICY "anon_delete_mint_burn_log" ON mint_burn_log FOR DELETE
  TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_route_reserves_venue_id ON route_reserves(venue_id);
CREATE INDEX IF NOT EXISTS idx_oracle_feeds_symbol ON oracle_feeds(symbol);
CREATE INDEX IF NOT EXISTS idx_oracle_feeds_route_id ON oracle_feeds(route_id);
CREATE INDEX IF NOT EXISTS idx_synthetic_positions_wallet ON synthetic_positions(wallet_address);
CREATE INDEX IF NOT EXISTS idx_synthetic_positions_symbol ON synthetic_positions(asset_symbol);
CREATE INDEX IF NOT EXISTS idx_mint_burn_log_wallet ON mint_burn_log(wallet_address);
CREATE INDEX IF NOT EXISTS idx_mint_burn_log_created_at ON mint_burn_log(created_at DESC);
