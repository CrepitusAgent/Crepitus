/*
# Fix RLS Security & Move HTTP Extension

## Summary
Fixes all security warnings by:
1. Moving the `http` extension from `public` schema to `extensions` schema.
2. Dropping overly permissive INSERT, UPDATE, DELETE policies on all system tables
   that should only be writable by service_role (edge functions).
3. Keeping only SELECT policies for anon/authenticated on read-only tables.
4. For user_deposits: keeping SELECT + INSERT (client needs to insert), removing UPDATE + DELETE.

## Tables affected
- agent_activity: DROP insert/update/delete policies (writes via service_role only)
- agent_state: DROP insert/update/delete policies (writes via service_role only)
- oracle_feeds: DROP insert/update/delete policies (writes via service_role only)
- rebalances: DROP insert/update/delete policies (writes via service_role only)
- route_reserves: DROP insert/update/delete policies (writes via service_role only)
- synthetic_positions: DROP insert/update/delete policies (writes via service_role only)
- tokenized_assets: DROP insert/update/delete policies (writes via service_role only)
- venues: DROP insert/update/delete policies (writes via service_role only)
- vaults: DROP insert/update/delete policies (writes via service_role only)
- mint_burn_log: DROP insert/update/delete policies (writes via service_role only)
- user_deposits: DROP update/delete policies, KEEP select + insert

## Security changes
- http extension moved to `extensions` schema (out of public)
- All system tables locked to read-only for anon/authenticated
- user_deposits allows SELECT + INSERT only (no update/delete)
- All writes to system tables must go through edge functions (service_role bypasses RLS)
*/

-- 1. Move http extension from public to extensions schema
CREATE SCHEMA IF NOT EXISTS extensions;
DROP EXTENSION IF EXISTS http;
CREATE EXTENSION IF NOT EXISTS http SCHEMA extensions;

-- 2. Drop overly permissive policies on agent_activity
DROP POLICY IF EXISTS "anon_insert_agent_activity" ON agent_activity;
DROP POLICY IF EXISTS "anon_update_agent_activity" ON agent_activity;
DROP POLICY IF EXISTS "anon_delete_agent_activity" ON agent_activity;

-- 3. Drop overly permissive policies on agent_state
DROP POLICY IF EXISTS "anon_insert_agent_state" ON agent_state;
DROP POLICY IF EXISTS "anon_update_agent_state" ON agent_state;
DROP POLICY IF EXISTS "anon_delete_agent_state" ON agent_state;

-- 4. Drop overly permissive policies on oracle_feeds
DROP POLICY IF EXISTS "anon_insert_oracle_feeds" ON oracle_feeds;
DROP POLICY IF EXISTS "anon_update_oracle_feeds" ON oracle_feeds;
DROP POLICY IF EXISTS "anon_delete_oracle_feeds" ON oracle_feeds;

-- 5. Drop overly permissive policies on rebalances
DROP POLICY IF EXISTS "anon_insert_rebalances" ON rebalances;
DROP POLICY IF EXISTS "anon_update_rebalances" ON rebalances;
DROP POLICY IF EXISTS "anon_delete_rebalances" ON rebalances;

-- 6. Drop overly permissive policies on route_reserves
DROP POLICY IF EXISTS "anon_insert_route_reserves" ON route_reserves;
DROP POLICY IF EXISTS "anon_update_route_reserves" ON route_reserves;
DROP POLICY IF EXISTS "anon_delete_route_reserves" ON route_reserves;

-- 7. Drop overly permissive policies on synthetic_positions
DROP POLICY IF EXISTS "anon_insert_synthetic_positions" ON synthetic_positions;
DROP POLICY IF EXISTS "anon_update_synthetic_positions" ON synthetic_positions;
DROP POLICY IF EXISTS "anon_delete_synthetic_positions" ON synthetic_positions;

-- 8. Drop overly permissive policies on tokenized_assets
DROP POLICY IF EXISTS "anon_insert_tokenized_assets" ON tokenized_assets;
DROP POLICY IF EXISTS "anon_update_tokenized_assets" ON tokenized_assets;
DROP POLICY IF EXISTS "anon_delete_tokenized_assets" ON tokenized_assets;

-- 9. Drop overly permissive policies on venues
DROP POLICY IF EXISTS "anon_insert_venues" ON venues;
DROP POLICY IF EXISTS "anon_update_venues" ON venues;
DROP POLICY IF EXISTS "anon_delete_venues" ON venues;

-- 10. Drop overly permissive policies on vaults
DROP POLICY IF EXISTS "anon_insert_vaults" ON vaults;
DROP POLICY IF EXISTS "anon_update_vaults" ON vaults;
DROP POLICY IF EXISTS "anon_delete_vaults" ON vaults;

-- 11. Drop overly permissive policies on mint_burn_log
DROP POLICY IF EXISTS "anon_insert_mint_burn_log" ON mint_burn_log;
DROP POLICY IF EXISTS "anon_update_mint_burn_log" ON mint_burn_log;
DROP POLICY IF EXISTS "anon_delete_mint_burn_log" ON mint_burn_log;

-- 12. Fix user_deposits: remove update + delete, keep select + insert
DROP POLICY IF EXISTS "anon_update_user_deposits" ON user_deposits;
DROP POLICY IF EXISTS "anon_delete_user_deposits" ON user_deposits;
