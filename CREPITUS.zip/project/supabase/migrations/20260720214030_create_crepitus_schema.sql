/*
# Create Crepitus $CREP Schema

1. New Tables
  - `venues` - The six DeFi venues scored by the agent
    - `id` (uuid, primary key)
    - `name` (text) - venue name
    - `protocol` (text) - underlying protocol
    - `apy` (numeric) - current annual percentage yield
    - `liquidity_usd` (numeric) - total liquidity in USD
    - `risk_score` (numeric) - risk rating 0-100
    - `correlation` (numeric) - correlation factor 0-1
    - `slippage_bps` (numeric) - slippage in basis points
    - `composite_score` (numeric) - overall weighted score
    - `rank` (integer) - current rank
    - `updated_at` (timestamptz)

  - `rebalances` - Agent routing decisions log
    - `id` (uuid, primary key)
    - `executed_at` (timestamptz)
    - `from_venue` (text) - source venue
    - `to_venue` (text) - destination venue
    - `amount_usd` (numeric) - amount routed
    - `reason` (text) - why the rebalance happened
    - `tx_hash` (text) - transaction hash
    - `status` (text) - completed/pending/failed

  - `vaults` - Active core feature vaults
    - `id` (uuid, primary key)
    - `name` (text) - vault name
    - `type` (text) - stablecoin_savings/borrowing/tokenized_stocks/swaps
    - `tvl_usd` (numeric) - total value locked
    - `apy` (numeric) - current yield
    - `utilization` (numeric) - utilization rate 0-100
    - `status` (text) - active/paused

  - `tokenized_assets` - RWA and tokenized stock inventory
    - `id` (uuid, primary key)
    - `symbol` (text) - ticker symbol
    - `name` (text) - full name
    - `backing` (text) - XRPL or Robinhood
    - `price_usd` (numeric) - current price
    - `holder_count` (integer) - number of holders
    - `status` (text) - active/bridging/settled

  - `agent_activity` - Live agent event log
    - `id` (uuid, primary key)
    - `event_type` (text) - scoring/routing/bridging/monitoring/settled
    - `message` (text) - human-readable description
    - `payload` (jsonb) - structured event data
    - `created_at` (timestamptz)

  - `agent_state` - Singleton agent state row
    - `id` (integer, primary key, always 1)
    - `current_best_venue` (text)
    - `total_aum` (numeric)
    - `last_rebalance_at` (timestamptz)
    - `next_rebalance_at` (timestamptz)
    - `rebalance_count` (integer)
    - `total_yield_routed` (numeric)

2. Security
  - RLS enabled on all tables
  - Anon + authenticated can SELECT all tables (public dashboard)
  - Anon + authenticated can INSERT into agent_activity and rebalances (for edge functions)
  - Anon + authenticated can UPDATE venues and agent_state (for edge functions)
*/

-- Venues table
CREATE TABLE IF NOT EXISTS venues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  protocol text NOT NULL,
  apy numeric NOT NULL DEFAULT 0,
  liquidity_usd numeric NOT NULL DEFAULT 0,
  risk_score numeric NOT NULL DEFAULT 50,
  correlation numeric NOT NULL DEFAULT 0.5,
  slippage_bps numeric NOT NULL DEFAULT 10,
  composite_score numeric NOT NULL DEFAULT 0,
  rank integer NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE venues ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_venues" ON venues;
CREATE POLICY "anon_select_venues" ON venues FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_venues" ON venues;
CREATE POLICY "anon_insert_venues" ON venues FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_venues" ON venues;
CREATE POLICY "anon_update_venues" ON venues FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_venues" ON venues;
CREATE POLICY "anon_delete_venues" ON venues FOR DELETE
  TO anon, authenticated USING (true);

-- Rebalances table
CREATE TABLE IF NOT EXISTS rebalances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  executed_at timestamptz DEFAULT now(),
  from_venue text NOT NULL,
  to_venue text NOT NULL,
  amount_usd numeric NOT NULL DEFAULT 0,
  reason text NOT NULL,
  tx_hash text NOT NULL,
  status text NOT NULL DEFAULT 'completed'
);

ALTER TABLE rebalances ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_rebalances" ON rebalances;
CREATE POLICY "anon_select_rebalances" ON rebalances FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_rebalances" ON rebalances;
CREATE POLICY "anon_insert_rebalances" ON rebalances FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_rebalances" ON rebalances;
CREATE POLICY "anon_update_rebalances" ON rebalances FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_rebalances" ON rebalances;
CREATE POLICY "anon_delete_rebalances" ON rebalances FOR DELETE
  TO anon, authenticated USING (true);

-- Vaults table
CREATE TABLE IF NOT EXISTS vaults (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL,
  tvl_usd numeric NOT NULL DEFAULT 0,
  apy numeric NOT NULL DEFAULT 0,
  utilization numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active'
);

ALTER TABLE vaults ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_vaults" ON vaults;
CREATE POLICY "anon_select_vaults" ON vaults FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_vaults" ON vaults;
CREATE POLICY "anon_insert_vaults" ON vaults FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_vaults" ON vaults;
CREATE POLICY "anon_update_vaults" ON vaults FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_vaults" ON vaults;
CREATE POLICY "anon_delete_vaults" ON vaults FOR DELETE
  TO anon, authenticated USING (true);

-- Tokenized assets table
CREATE TABLE IF NOT EXISTS tokenized_assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  symbol text NOT NULL,
  name text NOT NULL,
  backing text NOT NULL DEFAULT 'XRPL',
  price_usd numeric NOT NULL DEFAULT 0,
  holder_count integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active'
);

ALTER TABLE tokenized_assets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_tokenized_assets" ON tokenized_assets;
CREATE POLICY "anon_select_tokenized_assets" ON tokenized_assets FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_tokenized_assets" ON tokenized_assets;
CREATE POLICY "anon_insert_tokenized_assets" ON tokenized_assets FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_tokenized_assets" ON tokenized_assets;
CREATE POLICY "anon_update_tokenized_assets" ON tokenized_assets FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_tokenized_assets" ON tokenized_assets;
CREATE POLICY "anon_delete_tokenized_assets" ON tokenized_assets FOR DELETE
  TO anon, authenticated USING (true);

-- Agent activity table
CREATE TABLE IF NOT EXISTS agent_activity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  message text NOT NULL,
  payload jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE agent_activity ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_agent_activity" ON agent_activity;
CREATE POLICY "anon_select_agent_activity" ON agent_activity FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_agent_activity" ON agent_activity;
CREATE POLICY "anon_insert_agent_activity" ON agent_activity FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_agent_activity" ON agent_activity;
CREATE POLICY "anon_update_agent_activity" ON agent_activity FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_agent_activity" ON agent_activity;
CREATE POLICY "anon_delete_agent_activity" ON agent_activity FOR DELETE
  TO anon, authenticated USING (true);

-- Agent state table (singleton)
CREATE TABLE IF NOT EXISTS agent_state (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  current_best_venue text NOT NULL DEFAULT '',
  total_aum numeric NOT NULL DEFAULT 0,
  last_rebalance_at timestamptz DEFAULT now(),
  next_rebalance_at timestamptz DEFAULT now() + interval '6 hours',
  rebalance_count integer NOT NULL DEFAULT 0,
  total_yield_routed numeric NOT NULL DEFAULT 0
);

ALTER TABLE agent_state ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_agent_state" ON agent_state;
CREATE POLICY "anon_select_agent_state" ON agent_state FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_agent_state" ON agent_state;
CREATE POLICY "anon_insert_agent_state" ON agent_state FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_agent_state" ON agent_state;
CREATE POLICY "anon_update_agent_state" ON agent_state FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_agent_state" ON agent_state;
CREATE POLICY "anon_delete_agent_state" ON agent_state FOR DELETE
  TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_rebalances_executed_at ON rebalances(executed_at DESC);
CREATE INDEX IF NOT EXISTS idx_agent_activity_created_at ON agent_activity(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_venues_rank ON venues(rank ASC);
