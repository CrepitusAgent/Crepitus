/*
# Create user_deposits table

1. New Tables
  - `user_deposits` - Tracks user deposit/withdraw actions in vaults
    - `id` (uuid, primary key)
    - `wallet_address` (text, not null) - the user's Ethereum wallet address
    - `vault_id` (uuid, FK to vaults) - which vault the action is for
    - `amount_usd` (numeric, not null) - dollar amount
    - `action` (text, not null) - 'deposit' or 'withdraw'
    - `created_at` (timestamptz, default now)

2. Security
  - RLS enabled
  - Anon + authenticated can SELECT and INSERT (wallet-based filtering in app)
  - Update and delete also permitted for operational flexibility

3. Indexes
  - Index on wallet_address for fast lookup
  - Index on vault_id for joins
*/

CREATE TABLE IF NOT EXISTS user_deposits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_address text NOT NULL,
  vault_id uuid NOT NULL REFERENCES vaults(id),
  amount_usd numeric NOT NULL,
  action text NOT NULL CHECK (action IN ('deposit', 'withdraw')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE user_deposits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_user_deposits" ON user_deposits;
CREATE POLICY "anon_select_user_deposits" ON user_deposits FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_user_deposits" ON user_deposits;
CREATE POLICY "anon_insert_user_deposits" ON user_deposits FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_user_deposits" ON user_deposits;
CREATE POLICY "anon_update_user_deposits" ON user_deposits FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_user_deposits" ON user_deposits;
CREATE POLICY "anon_delete_user_deposits" ON user_deposits FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_user_deposits_wallet ON user_deposits(wallet_address);
CREATE INDEX IF NOT EXISTS idx_user_deposits_vault ON user_deposits(vault_id);
