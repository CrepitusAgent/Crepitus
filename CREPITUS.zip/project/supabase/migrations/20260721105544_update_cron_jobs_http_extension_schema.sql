/*
# Update cron jobs to use extensions.http_post

## Summary
After moving the `http` extension from `public` to `extensions` schema,
the cron jobs that call `http_post` need to be updated to use the
fully-qualified `extensions.http_post` function reference.

## Changes
- Unschedule and recrehedule both cron jobs with extensions-prefixed function calls.

## Important
- No data changes, only cron job command updates.
*/

-- Remove old jobs
SELECT cron.unschedule('crepitus-agent-rebalance');
SELECT cron.unschedule('crepitus-tick');

-- Recreate with extensions schema prefix
SELECT cron.schedule(
  'crepitus-agent-rebalance',
  '0 */6 * * *',
  $$
  SELECT extensions.http_post(
    current_setting('app.settings.supabase_url') || '/functions/v1/crepitus-agent',
    '{}',
    'application/json'
  );
  $$
);

SELECT cron.schedule(
  'crepitus-tick',
  '*/2 * * * *',
  $$
  SELECT extensions.http_post(
    current_setting('app.settings.supabase_url') || '/functions/v1/crepitus-tick',
    '{}',
    'application/json'
  );
  $$
);
