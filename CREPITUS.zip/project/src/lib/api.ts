import { supabase } from './supabase';

export interface Venue {
  id: string;
  name: string;
  protocol: string;
  apy: number;
  liquidity_usd: number;
  risk_score: number;
  correlation: number;
  slippage_bps: number;
  composite_score: number;
  rank: number;
  updated_at: string;
}

export interface Rebalance {
  id: string;
  executed_at: string;
  from_venue: string;
  to_venue: string;
  amount_usd: number;
  reason: string;
  tx_hash: string;
  status: string;
}

export interface Vault {
  id: string;
  name: string;
  type: string;
  tvl_usd: number;
  apy: number;
  utilization: number;
  status: string;
}

export interface TokenizedAsset {
  id: string;
  symbol: string;
  name: string;
  backing: string;
  price_usd: number;
  holder_count: number;
  status: string;
}

export interface AgentActivity {
  id: string;
  event_type: string;
  message: string;
  payload: Record<string, unknown>;
  created_at: string;
}

export interface AgentState {
  id: number;
  current_best_venue: string;
  total_aum: number;
  last_rebalance_at: string;
  next_rebalance_at: string;
  rebalance_count: number;
  total_yield_routed: number;
}

export interface UserDeposit {
  id: string;
  wallet_address: string;
  vault_id: string;
  amount_usd: number;
  action: 'deposit' | 'withdraw';
  created_at: string;
}

export async function fetchVenues(): Promise<Venue[]> {
  const { data, error } = await supabase
    .from('venues')
    .select('*')
    .order('rank', { ascending: true });
  if (error) throw error;
  return data || [];
}

export async function fetchRebalances(limit = 10): Promise<Rebalance[]> {
  const { data, error } = await supabase
    .from('rebalances')
    .select('*')
    .order('executed_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return data || [];
}

export async function fetchVaults(): Promise<Vault[]> {
  const { data, error } = await supabase
    .from('vaults')
    .select('*')
    .order('tvl_usd', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function fetchTokenizedAssets(): Promise<TokenizedAsset[]> {
  const { data, error } = await supabase
    .from('tokenized_assets')
    .select('*')
    .order('holder_count', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function fetchAgentActivity(limit = 30): Promise<AgentActivity[]> {
  const { data, error } = await supabase
    .from('agent_activity')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return data || [];
}

export async function fetchAgentState(): Promise<AgentState | null> {
  const { data, error } = await supabase
    .from('agent_state')
    .select('*')
    .eq('id', 1)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function fetchUserDeposits(walletAddress: string): Promise<UserDeposit[]> {
  const { data, error } = await supabase
    .from('user_deposits')
    .select('*')
    .eq('wallet_address', walletAddress.toLowerCase())
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function insertUserDeposit(
  walletAddress: string,
  vaultId: string,
  amountUsd: number,
  action: 'deposit' | 'withdraw'
): Promise<UserDeposit> {
  const { data, error } = await supabase
    .from('user_deposits')
    .insert({
      wallet_address: walletAddress.toLowerCase(),
      vault_id: vaultId,
      amount_usd: amountUsd,
      action,
    })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function triggerManualRebalance(): Promise<{ success: boolean; winner?: string; rebalanced?: boolean; error?: string }> {
  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/crepitus-agent`;
  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: '{}',
  });
  if (!response.ok) {
    throw new Error(`Rebalance failed (${response.status})`);
  }
  return response.json();
}

// ─── Asset Layer Types ─────────────────────────────────────────

export interface RouteReserve {
  id: string;
  venue_id: string;
  total_crep_locked: number;
  total_shares_outstanding: number;
  current_nav: number;
  oracle_price_usd: number;
  reserve_ratio_pct: number;
  last_oracle_update: string;
  status: string;
}

export interface OracleFeed {
  id: string;
  symbol: string;
  name: string;
  price_usd: number;
  prev_price_usd: number;
  source: string;
  route_id: string;
  last_updated: string;
}

export interface SyntheticPosition {
  id: string;
  wallet_address: string;
  asset_symbol: string;
  asset_name: string;
  shares_minted: number;
  nav_per_share: number;
  crep_locked: number;
  reserve_ratio: number;
  minted_at: string;
  status: string;
}

export interface MintBurnEntry {
  id: string;
  wallet_address: string;
  action: 'mint' | 'redeem';
  asset_symbol: string;
  shares: number;
  crep_amount: number;
  nav_at_execution: number;
  tx_hash: string;
  created_at: string;
}

// ─── Asset Layer Fetchers ──────────────────────────────────────

export async function fetchRouteReserves(): Promise<RouteReserve[]> {
  const { data, error } = await supabase
    .from('route_reserves')
    .select('*')
    .order('total_crep_locked', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function fetchOracleFeeds(): Promise<OracleFeed[]> {
  const { data, error } = await supabase
    .from('oracle_feeds')
    .select('*')
    .order('symbol', { ascending: true });
  if (error) throw error;
  return data || [];
}

export async function fetchSyntheticPositions(walletAddress: string): Promise<SyntheticPosition[]> {
  const { data, error } = await supabase
    .from('synthetic_positions')
    .select('*')
    .eq('wallet_address', walletAddress.toLowerCase())
    .eq('status', 'open')
    .order('minted_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function fetchMintBurnLog(walletAddress: string): Promise<MintBurnEntry[]> {
  const { data, error } = await supabase
    .from('mint_burn_log')
    .select('*')
    .eq('wallet_address', walletAddress.toLowerCase())
    .order('created_at', { ascending: false })
    .limit(20);
  if (error) throw error;
  return data || [];
}

export async function mintSynthetic(
  walletAddress: string,
  assetSymbol: string,
  crepAmount: number
): Promise<{ success: boolean; shares_minted?: number; tx_hash?: string; error?: string }> {
  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/crepitus-mint`;
  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      action: 'mint',
      wallet_address: walletAddress,
      asset_symbol: assetSymbol,
      crep_amount: crepAmount,
    }),
  });
  const result = await response.json();
  if (!response.ok) {
    throw new Error(result.error || `Mint failed (${response.status})`);
  }
  return result;
}

export async function redeemSynthetic(
  walletAddress: string,
  assetSymbol: string,
  sharesToBurn: number
): Promise<{ success: boolean; crep_released?: number; tx_hash?: string; error?: string }> {
  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/crepitus-mint`;
  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      action: 'redeem',
      wallet_address: walletAddress,
      asset_symbol: assetSymbol,
      shares_to_burn: sharesToBurn,
    }),
  });
  const result = await response.json();
  if (!response.ok) {
    throw new Error(result.error || `Redeem failed (${response.status})`);
  }
  return result;
}

// ─── Price History ────────────────────────────────────────────

export interface PriceHistoryPoint {
  id: string;
  feed_id: string;
  symbol: string;
  price_usd: number;
  prev_price_usd: number;
  recorded_at: string;
}

export async function fetchPriceHistory(symbol: string, hours: number = 24): Promise<PriceHistoryPoint[]> {
  const since = new Date(Date.now() - hours * 3600 * 1000).toISOString();
  const { data, error } = await supabase
    .from('oracle_price_history')
    .select('*')
    .eq('symbol', symbol)
    .gte('recorded_at', since)
    .order('recorded_at', { ascending: true });
  if (error) throw error;
  return data || [];
}

// ─── Alerts ──────────────────────────────────────────────────

export interface Alert {
  id: string;
  wallet_address: string;
  alert_type: string;
  asset_symbol: string | null;
  condition: string;
  threshold: number;
  is_active: boolean;
  last_triggered_at: string | null;
  created_at: string;
}

export interface AlertEvent {
  id: string;
  alert_id: string;
  triggered_at: string;
  trigger_value: number;
  message: string;
}

export async function fetchAlerts(walletAddress: string): Promise<Alert[]> {
  const { data, error } = await supabase
    .from('alerts')
    .select('*')
    .eq('wallet_address', walletAddress.toLowerCase())
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function createAlert(alert: { wallet_address: string; alert_type: string; asset_symbol: string | null; condition: string; threshold: number }): Promise<Alert> {
  const { data, error } = await supabase
    .from('alerts')
    .insert({
      wallet_address: alert.wallet_address.toLowerCase(),
      alert_type: alert.alert_type,
      asset_symbol: alert.asset_symbol,
      condition: alert.condition,
      threshold: alert.threshold,
    })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteAlert(alertId: string): Promise<void> {
  const { error } = await supabase.from('alerts').delete().eq('id', alertId);
  if (error) throw error;
}

export async function fetchAlertEvents(alertIds: string[]): Promise<AlertEvent[]> {
  if (alertIds.length === 0) return [];
  const { data, error } = await supabase
    .from('alert_events')
    .select('*')
    .in('alert_id', alertIds)
    .order('triggered_at', { ascending: false })
    .limit(20);
  if (error) throw error;
  return data || [];
}

// ─── Email Subscriptions ─────────────────────────────────────

export async function subscribeEmail(
  email: string,
  walletAddress?: string,
  preferences?: Record<string, boolean>
): Promise<void> {
  const { error } = await supabase
    .from('email_subscriptions')
    .upsert({
      email: email.toLowerCase(),
      wallet_address: walletAddress?.toLowerCase() || null,
      preferences: preferences || { price_alerts: true, weekly_summary: true, protocol_updates: true },
    }, { onConflict: 'email' });
  if (error) throw error;
}

// ─── Chat ────────────────────────────────────────────────────

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  sources?: string[];
}

export async function sendChatMessage(
  message: string,
  history: ChatMessage[],
  context: Record<string, unknown>
): Promise<{ reply: string; sources: string[]; suggestions: string[] }> {
  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/crepitus-chat`;
  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ message, history: history.slice(-10), context }),
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || `Chat failed (${response.status})`);
  }
  return response.json();
}
