import { useState, useEffect, useCallback } from 'react';

interface WalletState {
  address: string | null;
  chainId: string | null;
  connected: boolean;
  connecting: boolean;
  error: string | null;
}

export function useWallet() {
  const [state, setState] = useState<WalletState>({
    address: null,
    chainId: null,
    connected: false,
    connecting: false,
    error: null,
  });

  const hasProvider = typeof window !== 'undefined' && window.ethereum;

  const connect = useCallback(async () => {
    if (!hasProvider) {
      setState(s => ({ ...s, error: 'MetaMask not installed' }));
      return;
    }

    setState(s => ({ ...s, connecting: true, error: null }));

    try {
      const accounts = await window.ethereum!.request({
        method: 'eth_requestAccounts',
      }) as string[];

      const chainId = await window.ethereum!.request({
        method: 'eth_chainId',
      }) as string;

      setState({
        address: accounts[0] || null,
        chainId,
        connected: !!accounts[0],
        connecting: false,
        error: null,
      });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Connection failed';
      setState(s => ({ ...s, connecting: false, error: message }));
    }
  }, [hasProvider]);

  const disconnect = useCallback(() => {
    setState({
      address: null,
      chainId: null,
      connected: false,
      connecting: false,
      error: null,
    });
  }, []);

  useEffect(() => {
    if (!hasProvider) return;

    const handleAccountsChanged = (accounts: string[]) => {
      if (accounts.length === 0) {
        disconnect();
      } else {
        setState(s => ({ ...s, address: accounts[0], connected: true }));
      }
    };

    const handleChainChanged = (chainId: string) => {
      setState(s => ({ ...s, chainId }));
    };

    window.ethereum!.on('accountsChanged', handleAccountsChanged);
    window.ethereum!.on('chainChanged', handleChainChanged);

    return () => {
      window.ethereum!.removeListener('accountsChanged', handleAccountsChanged);
      window.ethereum!.removeListener('chainChanged', handleChainChanged);
    };
  }, [hasProvider, disconnect]);

  return { ...state, connect, disconnect, hasProvider };
}
