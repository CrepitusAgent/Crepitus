import { useState, useEffect } from 'react';
import { ArrowRight, Layers, Coins, BarChart3, Mail, Check, Loader2 } from 'lucide-react';
import { subscribeEmail } from '../lib/api';

interface LandingPageProps {
  onEnter: () => void;
}

export function LandingPage({ onEnter }: LandingPageProps) {
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.5 });
  const [entered, setEntered] = useState(false);

  useEffect(() => {
    const handleMouse = (e: MouseEvent) => {
      setMousePos({
        x: e.clientX / window.innerWidth,
        y: e.clientY / window.innerHeight,
      });
    };
    window.addEventListener('mousemove', handleMouse);
    return () => window.removeEventListener('mousemove', handleMouse);
  }, []);

  const handleEnter = () => {
    setEntered(true);
    setTimeout(onEnter, 600);
  };

  const parallaxX = (mousePos.x - 0.5) * 20;
  const parallaxY = (mousePos.y - 0.5) * 15;
  const glowX = mousePos.x * 100;
  const glowY = mousePos.y * 100;

  return (
    <div
      className={`fixed inset-0 z-50 overflow-y-auto transition-all duration-700 ${entered ? 'opacity-0 scale-105' : 'opacity-100 scale-100'}`}
      style={{
        background: `
          radial-gradient(ellipse at ${glowX}% ${glowY}%, rgba(200, 230, 0, 0.12) 0%, transparent 45%),
          radial-gradient(ellipse at 80% 20%, rgba(200, 230, 0, 0.08) 0%, transparent 40%),
          radial-gradient(ellipse at 20% 90%, rgba(154, 184, 0, 0.08) 0%, transparent 45%),
          linear-gradient(180deg, #6a6a6a 0%, #7a7a7a 35%, #858585 70%, #7e7e7e 100%)
        `,
      }}
    >
      <div className="fixed inset-0 pointer-events-none noise-overlay opacity-30" />

      {/* Floating orbs */}
      <div
        className="fixed w-[420px] h-[420px] rounded-full pointer-events-none transition-transform duration-[2000ms] ease-out"
        style={{
          background: 'radial-gradient(circle, rgba(200, 230, 0, 0.15) 0%, transparent 70%)',
          left: `${mousePos.x * 100 - 21}%`,
          top: `${mousePos.y * 100 - 21}%`,
          filter: 'blur(70px)',
        }}
      />
      <div
        className="fixed pointer-events-none animate-float"
        style={{
          width: '260px',
          height: '260px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(200, 230, 0, 0.08) 0%, transparent 70%)',
          filter: 'blur(50px)',
          top: '15%',
          right: '8%',
        }}
      />
      <div
        className="fixed pointer-events-none animate-float"
        style={{
          width: '320px',
          height: '320px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(154, 184, 0, 0.1) 0%, transparent 70%)',
          filter: 'blur(60px)',
          bottom: '10%',
          left: '5%',
          animationDelay: '2s',
        }}
      />

      {/* Nav */}
      <nav className="relative z-10 flex items-center justify-end px-6 md:px-12 py-6">
        <button
          onClick={handleEnter}
          className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 hover:scale-105 active:scale-95"
          style={{ background: 'rgba(200, 230, 0, 0.85)', color: '#1a2600', boxShadow: '0 0 30px rgba(200, 230, 0, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.4)' }}
        >
          Launch App
          <ArrowRight className="w-4 h-4" />
        </button>
      </nav>

      {/* Hero content - split layout */}
      <div className="relative z-10 flex flex-col lg:flex-row items-start justify-center gap-10 lg:gap-16 px-6 md:px-12 py-8 lg:py-12 min-h-[calc(100vh-88px)] max-w-6xl mx-auto">
        {/* Image + email left column */}
        <div className="flex flex-col items-center lg:items-start gap-6 flex-shrink-0">
          <div
            className="relative transition-transform duration-700 ease-out animate-slide-up"
            style={{ transform: `translate(${parallaxX}px, ${parallaxY}px)`, animationDelay: '0.05s' }}
          >
            <div className="absolute inset-0 rounded-[3rem]" style={{ background: 'radial-gradient(ellipse at center, rgba(200, 230, 0, 0.2) 0%, transparent 70%)', filter: 'blur(40px)', transform: 'scale(1.3)' }} />

            <img
              src="/images/CREPITUS copy.jpeg"
              alt="Crepitus Agent"
              className="relative max-w-[320px] lg:max-w-[400px] w-full h-auto rounded-[3rem] shadow-2xl"
              style={{
                boxShadow: '0 40px 80px rgba(0, 0, 0, 0.3), 0 0 80px rgba(200, 230, 0, 0.15)',
                border: '1.5px solid rgba(255, 255, 255, 0.25)',
              }}
            />
          </div>

          <EmailCapture />
        </div>

        {/* Text right */}
        <div className="flex-1 max-w-xl text-center lg:text-left">
          <div className="text-[11px] uppercase tracking-[0.3em] font-mono animate-slide-up" style={{ color: '#4a6600', animationDelay: '0.15s', opacity: 0, animationFillMode: 'forwards' }}>
            On-Chain Synthetic Equity Protocol
          </div>

          <h1 className="font-display font-bold text-4xl md:text-6xl leading-[0.95] mb-5 tracking-tight animate-slide-up" style={{ color: '#1a1a1a', animationDelay: '0.25s', opacity: 0, animationFillMode: 'forwards' }}>
            Collateral. Routes.<br />
            <span className="bg-clip-text text-transparent" style={{ backgroundImage: 'linear-gradient(135deg, #7c9000, #c8e600, #9ab800)' }}>Stocks.</span>
          </h1>

          <p className="text-base md:text-lg mb-8 leading-relaxed max-w-md mx-auto lg:mx-0 animate-slide-up" style={{ color: '#3a3a3a', animationDelay: '0.35s', opacity: 0, animationFillMode: 'forwards' }}>
            $CREP is collateral. Lock it into route reserves, mint synthetic equity positions backed by live oracle feeds, and trade on-chain stock exposure with no brokerage, no custodian, and no T+2 settlement.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-10 animate-slide-up" style={{ animationDelay: '0.45s', opacity: 0, animationFillMode: 'forwards' }}>
            <button
              onClick={handleEnter}
              className="group relative overflow-hidden inline-flex items-center justify-center gap-3 px-8 py-4 rounded-2xl text-base font-display font-bold transition-all duration-300 hover:scale-[1.03] active:scale-[0.97]"
              style={{
                background: 'linear-gradient(135deg, #c8e600, #9ab800)',
                color: '#1a2600',
                border: '1.5px solid rgba(255, 255, 255, 0.4)',
                boxShadow: '0 0 50px rgba(200, 230, 0, 0.35), 0 20px 40px rgba(0, 0, 0, 0.15), inset 0 1.5px 0 rgba(255, 255, 255, 0.5)',
              }}
            >
              <span className="relative z-10 flex items-center gap-3">
                Enter Dashboard
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </span>
              <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/40 to-transparent" />
            </button>
            <a
              href="https://ponsfamily.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-6 py-4 rounded-2xl text-base font-display font-semibold transition-all duration-200 hover:scale-[1.02]"
              style={{ background: 'rgba(255, 255, 255, 0.15)', border: '1.5px solid rgba(255, 255, 255, 0.3)', color: '#1a1a1a', boxShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.3)' }}
            >
              Buy $CREP
            </a>
          </div>

          {/* Three-Layer Architecture */}
          <div className="grid grid-cols-3 gap-3 pt-8 mt-2 max-w-lg mx-auto lg:mx-0 animate-slide-up" style={{ animationDelay: '0.55s', opacity: 0, animationFillMode: 'forwards', borderTop: '1px solid rgba(255, 255, 255, 0.15)' }}>
            <div className="p-4 rounded-xl text-center transition-all duration-200 hover:scale-[1.04]" style={{ background: 'rgba(255, 255, 255, 0.1)', border: '1px solid rgba(255, 255, 255, 0.2)', backdropFilter: 'blur(10px)' }}>
              <Layers className="w-4 h-4 mx-auto mb-2" style={{ color: '#4a4a4a' }} />
              <div className="text-[10px] uppercase tracking-widest text-surface-600 mb-1">Layer 1</div>
              <div className="text-xs font-display font-semibold text-surface-900">Deed</div>
              <div className="text-[10px] text-surface-600 mt-0.5">Route Yields</div>
            </div>
            <div className="p-4 rounded-xl text-center transition-all duration-200 hover:scale-[1.04]" style={{ background: 'rgba(255, 255, 255, 0.1)', border: '1px solid rgba(255, 255, 255, 0.2)', backdropFilter: 'blur(10px)' }}>
              <Coins className="w-4 h-4 mx-auto mb-2" style={{ color: '#4a4a4a' }} />
              <div className="text-[10px] uppercase tracking-widest text-surface-600 mb-1">Layer 2</div>
              <div className="text-xs font-display font-semibold text-surface-900">Token</div>
              <div className="text-[10px] text-surface-600 mt-0.5">$CREP Collateral</div>
            </div>
            <div className="p-4 rounded-xl text-center transition-all duration-200 hover:scale-[1.04]" style={{ background: 'rgba(200, 230, 0, 0.12)', border: '1px solid rgba(200, 230, 0, 0.3)', backdropFilter: 'blur(10px)', boxShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 0 15px rgba(200, 230, 0, 0.1)' }}>
              <BarChart3 className="w-4 h-4 mx-auto mb-2" style={{ color: '#4a6600' }} />
              <div className="text-[10px] uppercase tracking-widest mb-1" style={{ color: '#5a7a00' }}>Layer 3</div>
              <div className="text-xs font-display font-semibold" style={{ color: '#3a5500' }}>Asset</div>
              <div className="text-[10px] text-surface-600 mt-0.5">Synthetic Equities</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}

function EmailCapture() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) { setError('Enter a valid email'); return; }
    setLoading(true);
    setError('');
    try {
      await subscribeEmail(email, undefined, { protocol_updates: true, weekly_summary: true, price_alerts: false });
      setSuccess(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Subscription failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="p-6 rounded-2xl w-full max-w-[320px] lg:max-w-[400px] animate-slide-up"
      style={{
        animationDelay: '0.65s',
        opacity: 0,
        animationFillMode: 'forwards',
        background: 'rgba(255,255,255,0.08)',
        border: '1px solid rgba(255,255,255,0.15)',
        backdropFilter: 'blur(20px)',
      }}
    >
      {success ? (
        <div className="text-center py-2">
          <div className="w-10 h-10 rounded-full mx-auto mb-3 flex items-center justify-center" style={{ background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.2)' }}>
            <Check className="w-5 h-5 text-emerald-600" />
          </div>
          <p className="text-sm font-display font-semibold text-surface-900">You're in!</p>
          <p className="text-xs text-surface-600 mt-1">Exclusive protocol updates coming to your inbox.</p>
        </div>
      ) : (
        <>
          <div className="flex items-center gap-2 mb-3">
            <Mail className="w-4 h-4" style={{ color: '#4a6600' }} />
            <h3 className="text-sm font-display font-semibold text-surface-900">Get Exclusive Updates</h3>
          </div>
          <p className="text-xs text-surface-600 mb-4 leading-relaxed">
            Be the first to know about protocol launches, yield opportunities, and market insights.
          </p>
          <form onSubmit={handleSubmit} className="flex gap-2">
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="flex-1 px-3 py-2.5 rounded-xl text-xs text-surface-900 placeholder-surface-600 outline-none focus:ring-1 focus:ring-lime-500/30"
              style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)' }}
            />
            <button type="submit" disabled={loading} className="liquid-btn-primary text-xs px-4 py-2.5">
              {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Subscribe'}
            </button>
          </form>
          {error && <p className="text-xs text-red-500 mt-2">{error}</p>}
        </>
      )}
    </div>
  );
}
