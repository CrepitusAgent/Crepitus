import { useCallback } from 'react';
import { Layers, Globe, Users, DollarSign, Lock, TrendingUp, TrendingDown } from 'lucide-react';
import { usePolling } from '../hooks/usePolling';
import { fetchTokenizedAssets, fetchOracleFeeds, fetchRouteReserves } from '../lib/api';
import { formatUSD } from '../lib/utils';

export function AssetsTab() {
  const fetcher = useCallback(() => fetchTokenizedAssets(), []);
  const feedsFetcher = useCallback(() => fetchOracleFeeds(), []);
  const reservesFetcher = useCallback(() => fetchRouteReserves(), []);
  const { data: assets } = usePolling(fetcher, 30000);
  const { data: feeds } = usePolling(feedsFetcher, 10000);
  const { data: reserves } = usePolling(reservesFetcher, 15000);

  const totalHolders = assets?.reduce((sum, a) => sum + a.holder_count, 0) || 0;
  const totalAssets = (assets?.length || 0) + (feeds?.length || 0);
  const totalLocked = reserves?.reduce((s, r) => s + r.total_crep_locked, 0) || 0;

  return (
    <div className="space-y-6 specular-sweep">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { icon: Layers, label: 'Listed Assets', value: totalAssets.toString(), color: 'text-surface-900', iconColor: 'text-surface-600' },
          { icon: Users, label: 'Total Holders', value: totalHolders.toLocaleString(), color: 'text-surface-900', iconColor: 'text-surface-600' },
          { icon: Lock, label: 'CREP Locked', value: `${(totalLocked / 1000000).toFixed(2)}M`, accent: true, iconColor: 'text-surface-600' },
          { icon: Globe, label: 'Backing Sources', value: '3', color: 'text-surface-900', iconColor: 'text-surface-600' },
        ].map((m, i) => (
          <div key={m.label} className="liquid-cell p-4 stagger-in" style={{ animationDelay: `${i * 60}ms` }}>
            <m.icon className={`w-4 h-4 ${m.iconColor} mb-2`} />
            <div className="text-[11px] uppercase tracking-wider text-surface-600 mb-1">{m.label}</div>
            {'accent' in m && m.accent ? (
              <div className="text-lg font-mono font-bold" style={{ color: '#4a6600' }}>{m.value}</div>
            ) : (
              <div className={`text-lg font-mono font-bold ${m.color}`}>{m.value}</div>
            )}
          </div>
        ))}
      </div>

      {/* Synthetic Equities (Oracle-backed) */}
      {feeds && feeds.length > 0 && (
        <div className="liquid-glass overflow-hidden">
          <div className="flex items-center gap-2.5 p-5 pb-0 mb-3">
            <TrendingUp className="w-4 h-4" style={{ color: '#4a6600' }} />
            <h3 className="font-display font-semibold text-surface-900 text-sm">Synthetic Equities</h3>
            <span className="liquid-pill-lime text-[10px] ml-auto">Route-Reserve Backed</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-surface-600 text-[11px] uppercase tracking-wider" style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.04)' }}>
                  <th className="text-left py-3 px-5 font-medium">Asset</th>
                  <th className="text-right py-3 px-5 font-medium">NAV / Share</th>
                  <th className="text-right py-3 px-5 font-medium">Change</th>
                  <th className="text-right py-3 px-5 font-medium">Reserve Ratio</th>
                  <th className="text-right py-3 px-5 font-medium">CREP Locked</th>
                  <th className="text-right py-3 px-5 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {feeds.map((feed, i) => {
                  const reserve = reserves?.find(r => r.id === feed.route_id);
                  const delta = feed.price_usd - feed.prev_price_usd;
                  const deltaPct = feed.prev_price_usd > 0 ? (delta / feed.prev_price_usd) * 100 : 0;
                  const isUp = delta >= 0;
                  return (
                    <tr key={feed.id} className="liquid-row stagger-in" style={{ animationDelay: `${i * 40}ms` }}>
                      <td className="py-3.5 px-5">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg flex items-center justify-center font-mono font-bold text-xs" style={{ color: '#4a6600', background: 'rgba(200, 230, 0, 0.06)', border: '1px solid rgba(200, 230, 0, 0.1)' }}>
                            {feed.symbol.slice(0, 2)}
                          </div>
                          <div>
                            <div className="font-display font-semibold text-surface-900">s{feed.symbol}</div>
                            <div className="text-[11px] text-surface-600">{feed.name}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-5 text-right font-mono font-medium text-surface-900">
                        ${feed.price_usd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-3.5 px-5 text-right">
                        <span className={`inline-flex items-center gap-1 text-xs font-mono ${isUp ? 'text-emerald-700' : 'text-red-600'}`}>
                          {isUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                          {isUp ? '+' : ''}{deltaPct.toFixed(2)}%
                        </span>
                      </td>
                      <td className="py-3.5 px-5 text-right">
                        <span className={`font-mono text-xs ${(reserve?.reserve_ratio_pct || 0) >= 150 ? 'text-emerald-700' : (reserve?.reserve_ratio_pct || 0) >= 130 ? 'text-amber-600' : 'text-red-600'}`}>
                          {reserve?.reserve_ratio_pct.toFixed(0) || '--'}%
                        </span>
                      </td>
                      <td className="py-3.5 px-5 text-right font-mono text-surface-600 text-xs">
                        {reserve ? formatUSD(reserve.total_crep_locked) : '--'}
                      </td>
                      <td className="py-3.5 px-5 text-right">
                        <span className="inline-flex items-center gap-1.5">
                          <div className="w-1.5 h-1.5 rounded-full bg-emerald-600" style={{ boxShadow: '0 0 6px rgba(34, 197, 94, 0.4)' }} />
                          <span className="text-xs text-surface-600">Active</span>
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Legacy Tokenized Assets */}
      <div className="liquid-glass overflow-hidden">
        <div className="flex items-center gap-2.5 p-5 pb-0 mb-3">
          <Layers className="w-4 h-4 text-surface-600" />
          <h3 className="font-display font-semibold text-surface-900 text-sm">Tokenized Assets</h3>
          <span className="liquid-pill text-[10px] ml-auto">XRPL Backed</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-surface-600 text-[11px] uppercase tracking-wider" style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.04)' }}>
                <th className="text-left py-3.5 px-5 font-medium">Asset</th>
                <th className="text-left py-3.5 px-5 font-medium">Backing</th>
                <th className="text-right py-3.5 px-5 font-medium">Price</th>
                <th className="text-right py-3.5 px-5 font-medium">Holders</th>
                <th className="text-right py-3.5 px-5 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {assets?.map((asset, i) => (
                <tr key={asset.id} className="liquid-row stagger-in" style={{ animationDelay: `${i * 40}ms` }}>
                  <td className="py-3.5 px-5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center font-mono font-bold text-xs text-surface-600" style={{ background: 'rgba(255, 255, 255, 0.04)', border: '1px solid rgba(255, 255, 255, 0.06)' }}>
                        {asset.symbol.slice(1, 3)}
                      </div>
                      <div>
                        <div className="font-display font-semibold text-surface-900">{asset.symbol}</div>
                        <div className="text-[11px] text-surface-600">{asset.name}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-5">
                    <span className={`liquid-pill${asset.backing === 'XRPL' ? '-lime' : ''} text-[10px]`}>
                      {asset.backing}
                    </span>
                  </td>
                  <td className="py-3.5 px-5 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <DollarSign className="w-3 h-3 text-surface-600" />
                      <span className="font-mono font-medium text-surface-900">{asset.price_usd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-5 text-right font-mono text-surface-600">{asset.holder_count.toLocaleString()}</td>
                  <td className="py-3.5 px-5 text-right">
                    <span className="inline-flex items-center gap-1.5">
                      <div className={`w-1.5 h-1.5 rounded-full ${
                        asset.status === 'active' ? 'bg-emerald-600' :
                        asset.status === 'bridging' ? 'bg-amber-600' : 'bg-surface-400'
                      }`} style={{ boxShadow: asset.status === 'active' ? '0 0 6px rgba(34, 197, 94, 0.4)' : 'none' }} />
                      <span className="text-xs text-surface-600 capitalize">{asset.status}</span>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!assets && (
          <div className="p-5 space-y-3">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="shimmer h-12 rounded-lg" />)}
          </div>
        )}
      </div>
    </div>
  );
}
