import { useCallback, useMemo } from 'react';
import { Shield, AlertTriangle, Activity, Clock, Lock } from 'lucide-react';
import { usePolling } from '../hooks/usePolling';
import { fetchRouteReserves, fetchOracleFeeds, fetchVenues, type RouteReserve, type OracleFeed, type Venue } from '../lib/api';
import { formatUSD } from '../lib/utils';

export function RiskTab() {
  const reservesFetcher = useCallback(() => fetchRouteReserves(), []);
  const feedsFetcher = useCallback(() => fetchOracleFeeds(), []);
  const venuesFetcher = useCallback(() => fetchVenues(), []);
  const { data: reserves } = usePolling(reservesFetcher, 10000);
  const { data: feeds } = usePolling(feedsFetcher, 8000);
  const { data: venues } = usePolling(venuesFetcher, 12000);

  const metrics = useMemo(() => {
    const reserveList = reserves || [];
    const feedList = feeds || [];
    const venueList = venues || [];

    const avgRatio = reserveList.length > 0 ? reserveList.reduce((s, r) => s + r.reserve_ratio_pct, 0) / reserveList.length : 150;
    const reserveScore = Math.max(0, Math.min(100, ((avgRatio - 130) / 70) * 100));

    const now = Date.now();
    const staleTimes = feedList.map(f => (now - new Date(f.last_updated).getTime()) / 1000);
    const maxStale = staleTimes.length > 0 ? Math.max(...staleTimes) : 0;
    const oracleScore = maxStale < 120 ? 100 : maxStale < 300 ? 70 : maxStale < 600 ? 40 : 10;

    const totalLocked = reserveList.reduce((s, r) => s + r.total_crep_locked, 0);
    const hhi = totalLocked > 0 ? reserveList.reduce((s, r) => s + Math.pow(r.total_crep_locked / totalLocked, 2), 0) : 1;
    const diversityScore = Math.max(0, Math.min(100, (1 - hhi) * 130));

    const avgVenueRisk = venueList.length > 0 ? venueList.reduce((s, v) => s + v.risk_score, 0) / venueList.length : 50;
    const overallScore = reserveScore * 0.4 + oracleScore * 0.2 + diversityScore * 0.2 + (100 - avgVenueRisk) * 0.2;

    return { overallScore, reserveScore, oracleScore, diversityScore };
  }, [reserves, feeds, venues]);

  return (
    <div className="space-y-6 specular-sweep">
      {/* Protocol Health Score */}
      <div className="liquid-glass-elevated p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'rgba(200, 230, 0, 0.1)', border: '1px solid rgba(200, 230, 0, 0.2)' }}>
            <Shield className="w-4 h-4" style={{ color: '#4a6600' }} />
          </div>
          <div>
            <h2 className="font-display font-bold text-surface-900 text-lg">Protocol Health</h2>
            <p className="text-xs text-surface-600">Composite risk assessment across all protocol dimensions</p>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <ScoreCard label="Overall" value={metrics.overallScore} />
          <ScoreCard label="Reserve" value={metrics.reserveScore} />
          <ScoreCard label="Oracle" value={metrics.oracleScore} />
          <ScoreCard label="Diversity" value={metrics.diversityScore} />
        </div>
      </div>

      {/* Reserve Risk Map */}
      <div className="liquid-glass p-5">
        <div className="flex items-center gap-2.5 mb-4">
          <Lock className="w-4 h-4" style={{ color: '#4a6600' }} />
          <h3 className="font-display font-semibold text-surface-900 text-sm">Reserve Risk Map</h3>
        </div>
        <div className="space-y-3">
          {(reserves || []).map(r => {
            const feed = feeds?.find(f => f.route_id === r.id);
            const severity = r.reserve_ratio_pct >= 150 ? 'low' : r.reserve_ratio_pct >= 130 ? 'medium' : 'high';
            const barColor = severity === 'low' ? 'from-emerald-600/60 to-emerald-500/90' : severity === 'medium' ? 'from-amber-600/60 to-amber-500/90' : 'from-red-600/60 to-red-500/90';
            const textColor = severity === 'low' ? 'text-emerald-700' : severity === 'medium' ? 'text-amber-600' : 'text-red-600';
            return (
              <div key={r.id} className="liquid-cell p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-mono font-bold" style={{ color: '#4a6600', background: 'rgba(200,230,0,0.06)' }}>
                      {feed?.symbol?.slice(0, 2) || '??'}
                    </div>
                    <span className="text-xs font-medium text-surface-900">{feed ? `s${feed.symbol}` : 'Route'}</span>
                    {feed && <span className="text-[10px] text-surface-600">{feed.name}</span>}
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-surface-600">CREP: {formatUSD(r.total_crep_locked)}</span>
                    <span className={`text-sm font-mono font-bold ${textColor}`}>{r.reserve_ratio_pct.toFixed(0)}%</span>
                  </div>
                </div>
                <div className="liquid-progress">
                  <div className={`liquid-progress-fill bg-gradient-to-r ${barColor}`} style={{ width: `${Math.min(r.reserve_ratio_pct, 200) / 2}%` }} />
                </div>
                {severity !== 'low' && (
                  <div className="flex items-center gap-1.5 mt-2">
                    <AlertTriangle className={`w-3 h-3 ${textColor}`} />
                    <span className={`text-[10px] ${textColor}`}>
                      {severity === 'medium' ? 'Approaching minimum (130%)' : 'Below minimum -- minting restricted'}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
          {(!reserves || reserves.length === 0) && <div className="text-center py-6 text-xs text-surface-600">No reserves data</div>}
        </div>
      </div>

      {/* Oracle Staleness */}
      <div className="liquid-glass p-5">
        <div className="flex items-center gap-2.5 mb-4">
          <Clock className="w-4 h-4" style={{ color: '#4a6600' }} />
          <h3 className="font-display font-semibold text-surface-900 text-sm">Oracle Staleness Monitor</h3>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {(feeds || []).map(feed => {
            const ageSec = Math.floor((Date.now() - new Date(feed.last_updated).getTime()) / 1000);
            const isStale = ageSec > 300;
            const isAging = ageSec > 120;
            return (
              <div key={feed.id} className="liquid-cell p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-mono font-medium text-surface-900">{feed.symbol}</span>
                  <div className={`w-2 h-2 rounded-full ${isStale ? 'bg-red-500' : isAging ? 'bg-amber-500' : 'bg-emerald-500'}`} style={{ boxShadow: `0 0 4px ${isStale ? 'rgba(239,68,68,0.4)' : isAging ? 'rgba(245,158,11,0.4)' : 'rgba(34,197,94,0.4)'}` }} />
                </div>
                <div className="text-[10px] text-surface-600 font-mono">
                  {ageSec < 60 ? `${ageSec}s ago` : ageSec < 3600 ? `${Math.floor(ageSec / 60)}m ago` : `${Math.floor(ageSec / 3600)}h ago`}
                </div>
                {isStale && <div className="text-[10px] text-red-500 mt-1">STALE</div>}
              </div>
            );
          })}
        </div>
      </div>

      {/* Venue Risk Distribution */}
      <div className="liquid-glass p-5">
        <div className="flex items-center gap-2.5 mb-4">
          <Activity className="w-4 h-4" style={{ color: '#4a6600' }} />
          <h3 className="font-display font-semibold text-surface-900 text-sm">Venue Risk Distribution</h3>
        </div>
        <div className="space-y-2">
          {(venues || []).map(venue => {
            const riskColor = venue.risk_score < 30 ? 'text-emerald-700' : venue.risk_score < 60 ? 'text-amber-600' : 'text-red-600';
            const barColor = venue.risk_score < 30 ? 'from-emerald-600/60 to-emerald-500/90' : venue.risk_score < 60 ? 'from-amber-600/60 to-amber-500/90' : 'from-red-600/60 to-red-500/90';
            return (
              <div key={venue.id} className="liquid-row p-3 rounded-xl flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-mono font-bold text-surface-600" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}>
                  #{venue.rank}
                </div>
                <div className="flex-1">
                  <div className="text-xs font-medium text-surface-900">{venue.name}</div>
                  <div className="text-[10px] text-surface-600">{venue.protocol}</div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-24 liquid-progress">
                    <div className={`liquid-progress-fill bg-gradient-to-r ${barColor}`} style={{ width: `${venue.risk_score}%` }} />
                  </div>
                  <span className={`text-xs font-mono font-medium ${riskColor}`}>{venue.risk_score.toFixed(0)}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function ScoreCard({ label, value }: { label: string; value: number }) {
  const color = value >= 80 ? '#4a6600' : value >= 60 ? '#d97706' : '#dc2626';
  const barColor = value >= 80 ? 'from-emerald-600/60 to-lime-500/90' : value >= 60 ? 'from-amber-600/60 to-amber-500/90' : 'from-red-600/60 to-red-500/90';
  return (
    <div className="liquid-cell p-4">
      <span className="text-[10px] uppercase tracking-wider text-surface-600 font-medium">{label}</span>
      <div className="text-2xl font-mono font-bold mt-1 mb-2" style={{ color }}>{value.toFixed(0)}</div>
      <div className="liquid-progress">
        <div className={`liquid-progress-fill bg-gradient-to-r ${barColor}`} style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}
