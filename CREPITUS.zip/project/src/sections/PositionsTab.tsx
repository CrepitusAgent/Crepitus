import { useCallback, useState } from 'react';
import {
  BarChart3, Lock, Coins, TrendingUp, TrendingDown, ArrowUpRight,
  ArrowDownLeft, Wallet, X, Check, Loader2, ExternalLink, RefreshCw
} from 'lucide-react';
import { usePolling } from '../hooks/usePolling';
import { useWallet } from '../hooks/useWallet';
import {
  fetchRouteReserves, fetchOracleFeeds, fetchSyntheticPositions,
  fetchMintBurnLog, mintSynthetic, redeemSynthetic,
  type RouteReserve, type OracleFeed, type SyntheticPosition, type MintBurnEntry
} from '../lib/api';
import { formatUSD, timeAgo } from '../lib/utils';

export function PositionsTab() {
  const { connected, address, connect } = useWallet();

  const reservesFetcher = useCallback(() => fetchRouteReserves(), []);
  const feedsFetcher = useCallback(() => fetchOracleFeeds(), []);
  const { data: reserves } = usePolling(reservesFetcher, 10000);
  const { data: feeds } = usePolling(feedsFetcher, 8000);

  const positionsFetcher = useCallback(
    () => (address ? fetchSyntheticPositions(address) : Promise.resolve([])),
    [address]
  );
  const logFetcher = useCallback(
    () => (address ? fetchMintBurnLog(address) : Promise.resolve([])),
    [address]
  );
  const { data: positions, refetch: refetchPositions } = usePolling(positionsFetcher, 10000);
  const { data: mintLog, refetch: refetchLog } = usePolling(logFetcher, 10000);

  const [mintModalOpen, setMintModalOpen] = useState(false);
  const [selectedFeed, setSelectedFeed] = useState<OracleFeed | null>(null);

  const totalCrepLocked = reserves?.reduce((s, r) => s + r.total_crep_locked, 0) || 0;
  const totalShares = reserves?.reduce((s, r) => s + r.total_shares_outstanding, 0) || 0;
  const avgReserveRatio = reserves && reserves.length > 0
    ? reserves.reduce((s, r) => s + r.reserve_ratio_pct, 0) / reserves.length
    : 0;

  const openMint = (feed: OracleFeed) => {
    if (!connected) { connect(); return; }
    setSelectedFeed(feed);
    setMintModalOpen(true);
  };

  return (
    <div className="space-y-6 specular-sweep">
      {/* Reserve Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { icon: Lock, label: 'CREP Locked', value: `${(totalCrepLocked / 1000000).toFixed(2)}M`, color: 'text-surface-900' },
          { icon: Coins, label: 'Shares Outstanding', value: totalShares.toLocaleString(), color: 'text-surface-900' },
          { icon: BarChart3, label: 'Avg Reserve Ratio', value: `${avgReserveRatio.toFixed(0)}%`, color: 'text-surface-900' },
          { icon: RefreshCw, label: 'Equities Live', value: `${feeds?.length || 0}`, color: 'text-surface-900' },
        ].map((m, i) => (
          <div key={m.label} className="liquid-cell p-4 stagger-in" style={{ animationDelay: `${i * 60}ms` }}>
            <m.icon className={`w-4 h-4 ${i === 0 ? 'text-surface-600' : 'text-surface-600'} mb-2`} style={i === 0 ? { color: '#4a6600' } : {}} />
            <div className="text-[11px] uppercase tracking-wider text-surface-600 mb-1">{m.label}</div>
            <div className={`text-lg font-mono font-bold ${m.color}`} style={m.label === 'CREP Locked' || m.label === 'Avg Reserve Ratio' ? { color: '#4a6600' } : {}}>{m.value}</div>
          </div>
        ))}
      </div>

      {/* Oracle Feeds Table */}
      <div className="liquid-glass overflow-hidden">
        <div className="flex items-center gap-2.5 p-5 pb-0 mb-4">
          <TrendingUp className="w-4 h-4" style={{ color: '#4a6600' }} />
          <h3 className="font-display font-semibold text-surface-900 text-sm">Oracle Price Feeds</h3>
          <span className="liquid-pill text-[10px] ml-auto">Live</span>
          <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#4a6600', boxShadow: '0 0 8px rgba(200, 230, 0, 0.4)' }} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-surface-600 text-[11px] uppercase tracking-wider" style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.04)' }}>
                <th className="text-left py-3 px-5 font-medium">Equity</th>
                <th className="text-right py-3 px-5 font-medium">Price</th>
                <th className="text-right py-3 px-5 font-medium">Change</th>
                <th className="text-right py-3 px-5 font-medium">Source</th>
                <th className="text-right py-3 px-5 font-medium">Updated</th>
                <th className="text-center py-3 px-5 font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {feeds?.map((feed, i) => {
                const delta = feed.price_usd - feed.prev_price_usd;
                const deltaPct = feed.prev_price_usd > 0 ? (delta / feed.prev_price_usd) * 100 : 0;
                const isUp = delta >= 0;
                return (
                  <tr key={feed.id} className="liquid-row stagger-in" style={{ animationDelay: `${i * 30}ms` }}>
                    <td className="py-3.5 px-5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center font-mono font-bold text-xs" style={{ color: '#4a6600', background: 'rgba(200, 230, 0, 0.06)', border: '1px solid rgba(200, 230, 0, 0.1)' }}>
                          {feed.symbol.slice(0, 2)}
                        </div>
                        <div>
                          <div className="font-display font-semibold text-surface-900">s{feed.symbol}</div>
                          <div className="text-[11px] text-surface-600">{feed.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-5 text-right font-mono font-medium text-surface-900">
                      ${feed.price_usd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3.5 px-5 text-right">
                      <div className={`inline-flex items-center gap-1 text-xs font-mono ${isUp ? 'text-emerald-700' : 'text-red-600'}`}>
                        {isUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        {isUp ? '+' : ''}{deltaPct.toFixed(2)}%
                      </div>
                    </td>
                    <td className="py-3.5 px-5 text-right">
                      <span className="liquid-pill text-[10px]">Route Oracle</span>
                    </td>
                    <td className="py-3.5 px-5 text-right text-xs text-surface-600">
                      {timeAgo(feed.last_updated)}
                    </td>
                    <td className="py-3.5 px-5 text-center">
                      <button
                        onClick={() => openMint(feed)}
                        className="liquid-btn text-[11px] px-3 py-1.5"
                      >
                        Mint
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {!feeds && (
          <div className="p-5 space-y-3">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="shimmer h-12 rounded-lg" />)}
          </div>
        )}
      </div>

      {/* User Positions */}
      {connected && positions && positions.length > 0 && (
        <div className="liquid-glass p-5">
          <div className="flex items-center gap-2.5 mb-4">
            <Coins className="w-4 h-4" style={{ color: '#4a6600' }} />
            <h3 className="font-display font-semibold text-surface-900 text-sm">Your Synthetic Positions</h3>
            <span className="liquid-pill-lime text-[10px] ml-auto">{positions.length} open</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-surface-600 uppercase tracking-wider">
                  <th className="text-left pb-3 font-medium">Asset</th>
                  <th className="text-right pb-3 font-medium">Shares</th>
                  <th className="text-right pb-3 font-medium">NAV / Share</th>
                  <th className="text-right pb-3 font-medium">CREP Locked</th>
                  <th className="text-right pb-3 font-medium">Current Value</th>
                  <th className="text-center pb-3 font-medium">Action</th>
                </tr>
              </thead>
              <tbody>
                {positions.map(pos => {
                  const currentFeed = feeds?.find(f => f.symbol === pos.asset_symbol);
                  const currentValue = currentFeed ? pos.shares_minted * currentFeed.price_usd : pos.shares_minted * pos.nav_per_share;
                  return (
                    <tr key={pos.id} className="liquid-row">
                      <td className="py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded flex items-center justify-center font-mono text-[10px] font-bold" style={{ color: '#4a6600', background: 'rgba(200, 230, 0, 0.06)' }}>
                            {pos.asset_symbol.slice(0, 2)}
                          </div>
                          <div>
                            <span className="text-surface-900 font-medium">s{pos.asset_symbol}</span>
                            <div className="text-[10px] text-surface-600">{pos.asset_name}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 text-right font-mono text-surface-900">{pos.shares_minted.toFixed(2)}</td>
                      <td className="py-3 text-right font-mono text-surface-600">${pos.nav_per_share.toFixed(2)}</td>
                      <td className="py-3 text-right font-mono text-surface-600">{pos.crep_locked.toLocaleString()}</td>
                      <td className="py-3 text-right font-mono" style={{ color: '#4a6600' }}>{formatUSD(currentValue)}</td>
                      <td className="py-3 text-center">
                        <button
                          onClick={() => {
                            setSelectedFeed(feeds?.find(f => f.symbol === pos.asset_symbol) || null);
                            setMintModalOpen(true);
                          }}
                          className="liquid-btn text-[10px] px-2 py-1"
                        >
                          Redeem
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Mint/Burn History */}
      {connected && mintLog && mintLog.length > 0 && (
        <div className="liquid-glass p-5">
          <div className="flex items-center gap-2.5 mb-4">
            <ArrowUpRight className="w-4 h-4" style={{ color: '#4a6600' }} />
            <h3 className="font-display font-semibold text-surface-900 text-sm">Mint / Redeem History</h3>
          </div>
          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
            {mintLog.map((entry, i) => (
              <div key={entry.id} className="liquid-row p-3 rounded-xl flex items-center gap-3 stagger-in" style={{ animationDelay: `${i * 40}ms` }}>
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${entry.action === 'mint' ? '' : 'text-amber-600'}`}
                  style={{ color: entry.action === 'mint' ? '#4a6600' : undefined, background: entry.action === 'mint' ? 'rgba(200, 230, 0, 0.06)' : 'rgba(245, 158, 11, 0.06)', border: `1px solid ${entry.action === 'mint' ? 'rgba(200, 230, 0, 0.12)' : 'rgba(245, 158, 11, 0.12)'}` }}>
                  {entry.action === 'mint' ? <ArrowDownLeft className="w-3.5 h-3.5" /> : <ArrowUpRight className="w-3.5 h-3.5" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs text-surface-900 font-medium">
                    {entry.action === 'mint' ? 'Minted' : 'Redeemed'} {entry.shares.toFixed(2)} s{entry.asset_symbol}
                  </div>
                  <div className="text-[11px] text-surface-600">{entry.crep_amount.toLocaleString()} $CREP at NAV ${entry.nav_at_execution.toFixed(2)}</div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-[11px] text-surface-600">{timeAgo(entry.created_at)}</div>
                  <a href={`https://etherscan.io/tx/${entry.tx_hash}`} target="_blank" rel="noopener noreferrer" className="text-[10px] text-surface-600 hover:text-surface-900 transition-colors inline-flex items-center gap-0.5" style={{ ['--hover-color' as string]: '#4a6600' }}>
                    <ExternalLink className="w-2.5 h-2.5" /> tx
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Connect Wallet CTA */}
      {!connected && (
        <div className="liquid-glass p-8 text-center">
          <Wallet className="w-8 h-8 text-surface-600 mx-auto mb-3" />
          <p className="text-sm text-surface-600 mb-4">Connect your wallet to mint synthetic positions or view your portfolio</p>
          <button onClick={connect} className="liquid-btn text-xs">
            <Wallet className="w-3.5 h-3.5 mr-1.5" />
            Connect Wallet
          </button>
        </div>
      )}

      {/* Mint Modal */}
      {mintModalOpen && selectedFeed && (
        <MintModal
          feed={selectedFeed}
          walletAddress={address!}
          onClose={() => setMintModalOpen(false)}
          onSuccess={() => { setMintModalOpen(false); refetchPositions(); refetchLog(); }}
        />
      )}
    </div>
  );
}

function MintModal({ feed, walletAddress, onClose, onSuccess }: {
  feed: OracleFeed;
  walletAddress: string;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [mode, setMode] = useState<'mint' | 'redeem'>('mint');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [result, setResult] = useState<string>('');
  const [error, setError] = useState('');

  const previewShares = mode === 'mint' && amount
    ? (parseFloat(amount) / feed.price_usd).toFixed(4)
    : '';
  const previewCrep = mode === 'redeem' && amount
    ? (parseFloat(amount) * feed.price_usd).toFixed(0)
    : '';

  const handleSubmit = async () => {
    const num = parseFloat(amount);
    if (!num || num <= 0) { setError('Enter a valid amount'); return; }
    setLoading(true);
    setError('');
    try {
      if (mode === 'mint') {
        const res = await mintSynthetic(walletAddress, feed.symbol, num);
        setResult(`Minted ${res.shares_minted?.toFixed(4)} s${feed.symbol}`);
      } else {
        const res = await redeemSynthetic(walletAddress, feed.symbol, num);
        setResult(`Redeemed ${num} shares for ${res.crep_released?.toLocaleString()} $CREP`);
      }
      setSuccess(true);
      setTimeout(onSuccess, 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Transaction failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-panel" onClick={e => e.stopPropagation()}>
        {success ? (
          <div className="text-center py-8">
            <div className="w-14 h-14 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ background: 'rgba(34, 197, 94, 0.1)', border: '1px solid rgba(34, 197, 94, 0.2)', boxShadow: '0 0 6px rgba(34, 197, 94, 0.3)' }}>
              <Check className="w-7 h-7 text-emerald-700" />
            </div>
            <h3 className="font-display font-semibold text-surface-900 text-lg mb-1">
              {mode === 'mint' ? 'Position Minted' : 'Position Redeemed'}
            </h3>
            <p className="text-sm text-surface-600">{result}</p>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display font-semibold text-surface-900">
                {mode === 'mint' ? 'Mint' : 'Redeem'} s{feed.symbol}
              </h3>
              <button onClick={onClose} className="text-surface-600 hover:text-surface-900 transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mode Toggle */}
            <div className="flex gap-1 p-1 rounded-xl mb-5" style={{ background: 'rgba(255, 255, 255, 0.03)', border: '1px solid rgba(255, 255, 255, 0.06)' }}>
              <button
                onClick={() => setMode('mint')}
                className={`flex-1 text-xs font-medium py-2 rounded-lg transition-all ${mode === 'mint' ? '' : 'text-surface-600 hover:text-surface-900'}`}
                style={mode === 'mint' ? { color: '#4a6600', background: 'rgba(200, 230, 0, 0.1)', border: '1px solid rgba(200, 230, 0, 0.15)' } : {}}
              >
                Mint
              </button>
              <button
                onClick={() => setMode('redeem')}
                className={`flex-1 text-xs font-medium py-2 rounded-lg transition-all ${mode === 'redeem' ? 'text-amber-600' : 'text-surface-600 hover:text-surface-900'}`}
                style={mode === 'redeem' ? { background: 'rgba(245, 158, 11, 0.1)', border: '1px solid rgba(245, 158, 11, 0.15)' } : {}}
              >
                Redeem
              </button>
            </div>

            {/* Feed Info */}
            <div className="liquid-cell p-4 mb-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium text-surface-900">{feed.name}</div>
                  <div className="text-xs text-surface-600 mt-0.5">s{feed.symbol} -- Oracle NAV</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-mono font-bold" style={{ color: '#4a6600' }}>${feed.price_usd.toFixed(2)}</div>
                  <div className="text-[10px] text-surface-600">per share</div>
                </div>
              </div>
            </div>

            {/* Amount Input */}
            <div className="mb-4">
              <label className="text-xs text-surface-600 uppercase tracking-wider mb-2 block">
                {mode === 'mint' ? '$CREP Amount' : 'Shares to Burn'}
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-4 py-3 rounded-xl font-mono text-surface-900 text-lg placeholder-surface-600 focus:outline-none focus:ring-1 focus:ring-lime-500/30 transition-all"
                  style={{ background: 'rgba(255, 255, 255, 0.03)', border: '1px solid rgba(255, 255, 255, 0.08)' }}
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-surface-600">
                  {mode === 'mint' ? '$CREP' : 'shares'}
                </span>
              </div>
            </div>

            {/* Preview */}
            {(previewShares || previewCrep) && (
              <div className="p-3 rounded-xl mb-5" style={{ background: 'rgba(200, 230, 0, 0.04)', border: '1px solid rgba(200, 230, 0, 0.08)' }}>
                <div className="text-xs text-surface-600">
                  {mode === 'mint' ? 'You will receive' : 'You will release'}
                </div>
                <div className="text-sm font-mono font-bold mt-0.5" style={{ color: '#4a6600' }}>
                  {mode === 'mint' ? `${previewShares} s${feed.symbol}` : `${Number(previewCrep).toLocaleString()} $CREP`}
                </div>
              </div>
            )}

            {error && <div className="text-xs text-red-600 mb-4">{error}</div>}

            <button
              onClick={handleSubmit}
              disabled={loading}
              className="liquid-btn-primary w-full py-3 text-sm"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : mode === 'mint' ? (
                <ArrowDownLeft className="w-4 h-4 mr-2" />
              ) : (
                <ArrowUpRight className="w-4 h-4 mr-2" />
              )}
              {loading ? 'Processing...' : `Confirm ${mode === 'mint' ? 'Mint' : 'Redemption'}`}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
