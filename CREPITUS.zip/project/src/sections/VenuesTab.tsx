import { useCallback } from 'react';
import { Trophy, Shield, Droplets, TrendingUp, GitBranch, AlertTriangle, Zap } from 'lucide-react';
import { usePolling } from '../hooks/usePolling';
import { fetchVenues, type Venue } from '../lib/api';
import { formatUSD, formatPercent } from '../lib/utils';

export function VenuesTab() {
  const fetcher = useCallback(() => fetchVenues(), []);
  const { data: venues } = usePolling(fetcher, 12000);

  const winner = venues?.[0];

  return (
    <div className="space-y-6 specular-sweep">
      {winner && (
        <div className="liquid-glass-active p-4 flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4" style={{ color: '#4a6600' }} />
            <span className="text-xs text-surface-600">Current Leader:</span>
            <span className="text-sm font-display font-semibold text-surface-900">{winner.name}</span>
          </div>
          <span className="liquid-pill-lime">Score: {winner.composite_score.toFixed(1)}</span>
          <span className="liquid-pill-lime">APY: {formatPercent(winner.apy)}</span>
          <span className="liquid-pill">
            <Zap className="w-3 h-3" style={{ color: '#4a6600' }} />
            Active Route
          </span>
        </div>
      )}

      {venues && venues.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {venues.map((venue, i) => (
            <VenueCard key={venue.id} venue={venue} index={i} />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="shimmer h-72 rounded-2xl" />
          ))}
        </div>
      )}
    </div>
  );
}

function ScoreBar({ label, value, max, icon: Icon }: { label: string; value: number; max: number; icon: typeof TrendingUp }) {
  const pct = Math.min((value / max) * 100, 100);
  return (
    <div className="flex items-center gap-2.5">
      <Icon className="w-3 h-3 text-surface-600 flex-shrink-0" />
      <span className="text-[11px] text-surface-600 w-[72px] flex-shrink-0">{label}</span>
      <div className="flex-1 liquid-progress">
        <div className="liquid-progress-fill" style={{ width: `${pct}%` }} />
      </div>
      <span className="text-[11px] font-mono text-surface-600 w-10 text-right">{value.toFixed(1)}</span>
    </div>
  );
}

function VenueCard({ venue, index }: { venue: Venue; index: number }) {
  const isWinner = index === 0;

  return (
    <div
      className={`${isWinner ? 'liquid-glass-active' : 'liquid-glass hover:scale-[1.01]'} p-5 transition-all duration-300 stagger-in`}
      style={{ animationDelay: `${index * 60}ms` }}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div
            className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-mono font-bold ${
              isWinner ? '' : 'text-surface-600'
            }`}
            style={{ background: isWinner ? 'rgba(200, 230, 0, 0.12)' : 'rgba(255, 255, 255, 0.04)', border: `1px solid ${isWinner ? 'rgba(200, 230, 0, 0.2)' : 'rgba(255, 255, 255, 0.06)'}`, color: isWinner ? '#4a6600' : undefined }}
          >
            {isWinner ? <Trophy className="w-4 h-4" /> : `#${index + 1}`}
          </div>
          <div>
            <h4 className="font-display font-semibold text-surface-900 text-sm">{venue.name}</h4>
            <span className="text-[11px] text-surface-600">{venue.protocol}</span>
          </div>
        </div>
        <div className="text-right">
          <div className={`text-xl font-mono font-bold ${isWinner ? '' : 'text-surface-900'}`} style={isWinner ? { color: '#4a6600' } : undefined}>
            {venue.composite_score.toFixed(1)}
          </div>
          <div className="text-[10px] uppercase tracking-wider text-surface-600">score</div>
        </div>
      </div>

      <div className="space-y-2 mb-4">
        <ScoreBar label="APY" value={venue.apy} max={15} icon={TrendingUp} />
        <ScoreBar label="Liquidity" value={venue.liquidity_usd / 10000000} max={40} icon={Droplets} />
        <ScoreBar label="Safety" value={100 - venue.risk_score} max={100} icon={Shield} />
        <ScoreBar label="Decorrelation" value={(1 - venue.correlation) * 100} max={100} icon={GitBranch} />
        <ScoreBar label="Low Slippage" value={Math.max(0, 20 - venue.slippage_bps)} max={20} icon={AlertTriangle} />
      </div>

      <div className="flex items-center justify-between pt-3" style={{ borderTop: '1px solid rgba(255, 255, 255, 0.04)' }}>
        <span className="text-[11px] text-surface-600">
          APY <span className="font-mono font-medium" style={{ color: '#4a6600' }}>{formatPercent(venue.apy)}</span>
        </span>
        <span className="text-[11px] text-surface-600">
          TVL <span className="text-surface-900 font-mono font-medium">{formatUSD(venue.liquidity_usd)}</span>
        </span>
        <span className="text-[11px] text-surface-600">
          Risk <span className="text-surface-900 font-mono font-medium">{venue.risk_score.toFixed(0)}</span>
        </span>
      </div>

      {isWinner && (
        <div className="mt-3 flex items-center justify-center gap-1.5 py-1.5 rounded-lg" style={{ background: 'rgba(200, 230, 0, 0.06)' }}>
          <div className="agent-active-ring" style={{ width: '6px', height: '6px' }} />
          <span className="text-[11px] font-medium" style={{ color: '#4a6600' }}>Actively Routing Here</span>
        </div>
      )}
    </div>
  );
}
