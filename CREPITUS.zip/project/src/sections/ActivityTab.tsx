import { useCallback, useState } from 'react';
import { ScrollText, TrendingUp, ArrowRightLeft, Layers, Zap, Activity, Loader2, Play } from 'lucide-react';
import { usePolling } from '../hooks/usePolling';
import { useWallet } from '../hooks/useWallet';
import { fetchAgentActivity, triggerManualRebalance, type AgentActivity } from '../lib/api';
import { timeAgo } from '../lib/utils';

type FilterType = 'all' | 'scoring' | 'routing' | 'bridging' | 'monitoring' | 'settled';

export function ActivityTab() {
  const [filter, setFilter] = useState<FilterType>('all');
  const [triggerLoading, setTriggerLoading] = useState(false);
  const [triggerResult, setTriggerResult] = useState<string | null>(null);
  const { connected } = useWallet();

  const fetcher = useCallback(() => fetchAgentActivity(50), []);
  const { data: activities, refetch } = usePolling(fetcher, 5000);

  const filtered = activities?.filter(a =>
    filter === 'all' ? true : a.event_type === filter
  );

  const handleManualRebalance = async () => {
    setTriggerLoading(true);
    setTriggerResult(null);
    try {
      const result = await triggerManualRebalance();
      setTriggerResult(
        result.rebalanced
          ? `Rebalanced to ${result.winner}`
          : `No rebalance needed - ${result.winner} still optimal`
      );
      refetch();
    } catch (err) {
      setTriggerResult(err instanceof Error ? err.message : 'Failed');
    } finally {
      setTriggerLoading(false);
    }
  };

  const filters: { id: FilterType; label: string }[] = [
    { id: 'all', label: 'All' },
    { id: 'scoring', label: 'Scoring' },
    { id: 'routing', label: 'Routing' },
    { id: 'bridging', label: 'Bridging' },
    { id: 'monitoring', label: 'Monitor' },
    { id: 'settled', label: 'Settled' },
  ];

  const iconForType = (type: string) => {
    switch (type) {
      case 'scoring': return TrendingUp;
      case 'routing': return ArrowRightLeft;
      case 'bridging': return Layers;
      case 'settled': return Zap;
      default: return Activity;
    }
  };

  const colorForType = (type: string) => {
    switch (type) {
      case 'scoring': return 'text-blue-700';
      case 'routing': return 'text-[#4a6600]';
      case 'bridging': return 'text-amber-700';
      case 'settled': return 'text-emerald-700';
      default: return 'text-surface-600';
    }
  };

  const dotColorForType = (type: string) => {
    switch (type) {
      case 'scoring': return 'bg-blue-600';
      case 'routing': return 'bg-[#5a7a00]';
      case 'bridging': return 'bg-amber-600';
      case 'settled': return 'bg-emerald-600';
      default: return 'bg-surface-600';
    }
  };

  return (
    <div className="space-y-5 specular-sweep">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-1.5 flex-wrap">
          {filters.map(f => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`filter-pill ${filter === f.id ? 'filter-pill-active' : ''}`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {connected && (
          <button
            onClick={handleManualRebalance}
            disabled={triggerLoading}
            className="liquid-btn text-xs py-2 px-3"
          >
            {triggerLoading ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <Play className="w-3.5 h-3.5 mr-1.5" />}
            Trigger Rebalance
          </button>
        )}
      </div>

      {triggerResult && (
        <div className="liquid-cell p-3 flex items-center gap-2">
          <Zap className="w-3.5 h-3.5" style={{ color: '#4a6600' }} />
          <span className="text-xs font-medium" style={{ color: '#4a6600' }}>{triggerResult}</span>
        </div>
      )}

      <div className="liquid-glass overflow-hidden">
        <div className="divide-y divide-white/[0.025] max-h-[calc(100vh-260px)] overflow-y-auto">
          {filtered?.map((a, i) => {
            const Icon = iconForType(a.event_type);
            return (
              <div
                key={a.id}
                className="flex items-start gap-3 px-5 py-3.5 liquid-row stagger-in"
                style={{ animationDelay: `${i * 30}ms` }}
              >
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${colorForType(a.event_type)}`} style={{ background: 'rgba(255, 255, 255, 0.03)', border: '1px solid rgba(255, 255, 255, 0.05)' }}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <div className={`w-1.5 h-1.5 rounded-full ${dotColorForType(a.event_type)}`} style={{ boxShadow: `0 0 4px currentColor` }} />
                    <span className="text-[10px] uppercase tracking-wider text-surface-600">{a.event_type}</span>
                  </div>
                  <p className="text-xs text-surface-800 leading-relaxed">{a.message}</p>
                </div>
                <div className="flex-shrink-0 text-right">
                  <div className="text-[11px] font-mono text-surface-600">{timeAgo(a.created_at)}</div>
                </div>
              </div>
            );
          })}
          {!filtered && (
            <div className="p-5 space-y-2">
              {Array.from({ length: 10 }).map((_, i) => <div key={i} className="shimmer h-10 rounded-lg" />)}
            </div>
          )}
          {filtered?.length === 0 && (
            <div className="p-12 text-center">
              <ScrollText className="w-8 h-8 text-surface-600 mx-auto mb-3" />
              <p className="text-sm text-surface-600">No events matching this filter</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
