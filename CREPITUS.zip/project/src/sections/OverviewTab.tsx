import { useEffect, useState, useCallback } from 'react';
import {
  Activity, TrendingUp, TrendingDown, Zap, BarChart3,
  RefreshCw, Play, Eye, ArrowUpRight, Clock, Shield
} from 'lucide-react';
import { usePolling } from '../hooks/usePolling';
import {
  fetchAgentState, fetchVenues, fetchRebalances, fetchAgentActivity,
  fetchOracleFeeds, fetchRouteReserves, triggerManualRebalance,
  fetchPriceHistory,
  type AgentState, type Venue, type Rebalance, type AgentActivity,
  type OracleFeed, type RouteReserve, type PriceHistoryPoint,
} from '../lib/api';
import { formatUSD, timeAgo } from '../lib/utils';
import { PriceChart } from '../components/charts/PriceChart';
import { ChartPanel, type Timeframe } from '../components/charts/ChartPanel';

export function OverviewTab() {
  const { data: agentState } = usePolling<AgentState | null>(fetchAgentState, 8000);
  const { data: venues } = usePolling<Venue[]>(() => fetchVenues(), 10000);
  const { data: rebalances } = usePolling<Rebalance[]>(() => fetchRebalances(6), 10000);
  const { data: activity } = usePolling<AgentActivity[]>(() => fetchAgentActivity(8), 6000);
  const { data: oracles } = usePolling<OracleFeed[]>(fetchOracleFeeds, 8000);
  const { data: reserves } = usePolling<RouteReserve[]>(fetchRouteReserves, 10000);

  const [rebalancing, setRebalancing] = useState(false);
  const [rebalanceResult, setRebalanceResult] = useState<string | null>(null);

  const handleRebalance = useCallback(async () => {
    setRebalancing(true);
    setRebalanceResult(null);
    try {
      const res = await triggerManualRebalance();
      setRebalanceResult(res.rebalanced ? `Routed to ${res.winner}` : 'No rebalance needed');
    } catch (e: unknown) {
      setRebalanceResult(e instanceof Error ? e.message : 'Failed');
    } finally {
      setRebalancing(false);
      setTimeout(() => setRebalanceResult(null), 4000);
    }
  }, []);

  // Computed analytics from live data
  const analytics = computeAnalytics(oracles, venues, reserves, agentState);

  return (
    <div className="space-y-6 specular-sweep">
      {/* Market Pulse Hero */}
      <MarketPulse analytics={analytics} />

      {/* Quick Action Bar */}
      <div className="liquid-glass p-4 flex flex-wrap items-center gap-3">
        <button
          onClick={handleRebalance}
          disabled={rebalancing}
          className="liquid-btn-primary text-xs gap-2"
        >
          {rebalancing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
          {rebalancing ? 'Processing...' : 'Trigger Rebalance'}
        </button>
        <div className="h-6 w-px bg-white/[0.06]" />
        <div className="flex items-center gap-2 text-xs text-surface-600">
          <Clock className="w-3.5 h-3.5" />
          <span>Rebalances: <span className="text-surface-900 font-semibold">{agentState?.rebalance_count ?? '--'}</span></span>
        </div>
        <div className="flex items-center gap-2 text-xs text-surface-600">
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Yield Routed: <span className="font-semibold" style={{ color: '#4a6600' }}>{formatUSD(agentState?.total_yield_routed ?? 0)}</span></span>
        </div>
        {rebalanceResult && (
          <span className="liquid-pill-lime text-xs ml-auto animate-pulse">{rebalanceResult}</span>
        )}
      </div>

      {/* Oracle Momentum Strip */}
      <OracleMomentum oracles={oracles ?? []} />

      {/* Price Chart (expandable for selected feed) */}
      <PriceHistorySection feeds={oracles ?? []} />

      {/* Reserve Health + Rebalance History Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <ReserveHealth reserves={reserves ?? []} />
        <RebalanceHistory rebalances={rebalances ?? []} />
      </div>

      {/* Live Activity Feed */}
      <ActivityFeed activities={activity ?? []} />
    </div>
  );
}

// ─── Analytics Computation ──────────────────────────────────────

interface Analytics {
  portfolioHeat: number;
  capitalEfficiency: number;
  yieldVelocity: number;
  marketSentiment: number;
  topVenueApy: number;
  avgRisk: number;
}

function computeAnalytics(
  oracles: OracleFeed[] | null,
  venues: Venue[] | null,
  reserves: RouteReserve[] | null,
  agentState: AgentState | null
): Analytics {
  const feeds = oracles ?? [];
  const venueList = venues ?? [];
  const reserveList = reserves ?? [];

  // Portfolio Heat: avg absolute % price change across oracle feeds
  const priceChanges = feeds
    .filter(f => f.prev_price_usd > 0)
    .map(f => Math.abs((f.price_usd - f.prev_price_usd) / f.prev_price_usd) * 100);
  const portfolioHeat = priceChanges.length > 0
    ? priceChanges.reduce((a, b) => a + b, 0) / priceChanges.length
    : 0;

  // Capital Efficiency: avg reserve ratio
  const ratios = reserveList.filter(r => r.reserve_ratio_pct > 0).map(r => r.reserve_ratio_pct);
  const capitalEfficiency = ratios.length > 0
    ? ratios.reduce((a, b) => a + b, 0) / ratios.length
    : 0;

  // Yield Velocity: total yield / hours since first rebalance
  const yieldVelocity = agentState?.total_yield_routed ?? 0;

  // Market Sentiment: % of feeds trending up
  const upCount = feeds.filter(f => f.price_usd > f.prev_price_usd).length;
  const marketSentiment = feeds.length > 0 ? (upCount / feeds.length) * 100 : 50;

  // Top venue APY
  const topVenueApy = venueList.length > 0 ? Math.max(...venueList.map(v => v.apy)) : 0;

  // Average risk
  const avgRisk = venueList.length > 0
    ? venueList.reduce((a, v) => a + v.risk_score, 0) / venueList.length
    : 0;

  return { portfolioHeat, capitalEfficiency, yieldVelocity, marketSentiment, topVenueApy, avgRisk };
}

// ─── Market Pulse Component ─────────────────────────────────────

function MarketPulse({ analytics }: { analytics: Analytics }) {
  const metrics = [
    {
      label: 'Portfolio Heat',
      value: `${analytics.portfolioHeat.toFixed(2)}%`,
      icon: Activity,
      color: analytics.portfolioHeat > 2 ? 'text-orange-400' : '',
      style: analytics.portfolioHeat > 2 ? undefined : { color: '#4a6600' },
      desc: 'Avg price volatility',
    },
    {
      label: 'Capital Efficiency',
      value: `${analytics.capitalEfficiency.toFixed(1)}%`,
      icon: Shield,
      color: analytics.capitalEfficiency > 100 ? '' : 'text-amber-600',
      style: analytics.capitalEfficiency > 100 ? { color: '#4a6600' } : undefined,
      desc: 'Reserve backing ratio',
    },
    {
      label: 'Yield Velocity',
      value: formatUSD(analytics.yieldVelocity),
      icon: Zap,
      color: '',
      style: { color: '#4a6600' },
      desc: 'Total yield routed',
    },
    {
      label: 'Market Sentiment',
      value: `${analytics.marketSentiment.toFixed(0)}%`,
      icon: analytics.marketSentiment >= 50 ? TrendingUp : TrendingDown,
      color: analytics.marketSentiment >= 50 ? 'text-emerald-700' : 'text-red-600',
      style: undefined,
      desc: 'Feeds trending up',
    },
    {
      label: 'Top APY',
      value: `${analytics.topVenueApy.toFixed(2)}%`,
      icon: BarChart3,
      color: 'text-cyan-700',
      style: undefined,
      desc: 'Best venue yield',
    },
    {
      label: 'Avg Risk Score',
      value: analytics.avgRisk.toFixed(2),
      icon: Eye,
      color: analytics.avgRisk < 0.5 ? '' : 'text-amber-600',
      style: analytics.avgRisk < 0.5 ? { color: '#4a6600' } : undefined,
      desc: 'Protocol risk level',
    },
  ];

  return (
    <div className="liquid-glass-elevated p-6">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'rgba(200, 230, 0, 0.1)', border: '1px solid rgba(200, 230, 0, 0.2)' }}>
          <Activity className="w-4 h-4" style={{ color: '#4a6600' }} />
        </div>
        <div>
          <h2 className="font-display font-bold text-surface-900 text-lg">Synthetic Market Pulse</h2>
          <p className="text-xs text-surface-600">Real-time derived analytics from oracle and venue data</p>
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {metrics.map((m, i) => (
          <div
            key={m.label}
            className="liquid-cell p-4 stagger-in"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <div className="flex items-center gap-2 mb-2">
              <m.icon className={`w-3.5 h-3.5 ${m.color}`} style={m.style} />
              <span className="text-[10px] uppercase tracking-wider text-surface-600 font-medium">{m.label}</span>
            </div>
            <div className={`text-lg font-display font-bold ${m.color}`} style={m.style}>{m.value}</div>
            <div className="text-[10px] text-surface-600 mt-1">{m.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Oracle Momentum Strip ──────────────────────────────────────

function OracleMomentum({ oracles }: { oracles: OracleFeed[] }) {
  if (oracles.length === 0) return null;

  return (
    <div className="liquid-glass p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-semibold text-surface-900 text-sm">Oracle Feed Momentum</h3>
        <span className="text-[10px] text-surface-600 font-mono">{oracles.length} feeds active</span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {oracles.map((feed, i) => {
          const change = feed.prev_price_usd > 0
            ? ((feed.price_usd - feed.prev_price_usd) / feed.prev_price_usd) * 100
            : 0;
          const isUp = change >= 0;
          return (
            <div
              key={feed.id}
              className="liquid-cell p-3 stagger-in"
              style={{ animationDelay: `${i * 40}ms` }}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-mono font-semibold text-surface-900">{feed.symbol}</span>
                <MomentumBars change={change} />
              </div>
              <div className="text-xs font-mono text-surface-600">${feed.price_usd.toFixed(4)}</div>
              <div className={`text-[10px] font-mono flex items-center gap-1 mt-0.5 ${isUp ? 'text-emerald-700' : 'text-red-600'}`}>
                {isUp ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingDown className="w-2.5 h-2.5" />}
                {isUp ? '+' : ''}{change.toFixed(2)}%
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function MomentumBars({ change }: { change: number }) {
  const abs = Math.min(Math.abs(change), 5);
  const bars = Math.ceil((abs / 5) * 3) || 1;
  const color = change >= 0 ? 'bg-emerald-700' : 'bg-red-600';
  return (
    <div className="flex items-end gap-0.5 h-3">
      {[1, 2, 3].map(i => (
        <div
          key={i}
          className={`w-1 rounded-full transition-all duration-500 ${i <= bars ? color : 'bg-black/10'}`}
          style={{ height: `${(i / 3) * 100}%`, opacity: i <= bars ? 1 : 0.3 }}
        />
      ))}
    </div>
  );
}

// ─── Reserve Health ─────────────────────────────────────────────

function ReserveHealth({ reserves }: { reserves: RouteReserve[] }) {
  return (
    <div className="liquid-glass p-5">
      <h3 className="font-display font-semibold text-surface-900 text-sm mb-4">Reserve Health</h3>
      {reserves.length === 0 ? (
        <div className="text-surface-600 text-xs">No reserves yet</div>
      ) : (
        <div className="space-y-3">
          {reserves.map(r => {
            const ratio = r.reserve_ratio_pct;
            const color = ratio >= 110 ? '' : ratio >= 100 ? 'text-amber-600' : 'text-red-600';
            const colorStyle = ratio >= 110 ? { color: '#4a6600' } : undefined;
            const barColor = ratio >= 110
              ? 'from-lime-600/60 to-lime-500/90'
              : ratio >= 100
                ? 'from-amber-600/60 to-amber-500/90'
                : 'from-red-600/60 to-red-500/90';
            return (
              <div key={r.id} className="liquid-row p-3 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-surface-600 font-mono">{r.venue_id.slice(0, 8)}...</span>
                  <span className={`text-xs font-semibold font-mono ${color}`} style={colorStyle}>{ratio.toFixed(1)}%</span>
                </div>
                <div className="liquid-progress">
                  <div
                    className={`liquid-progress-fill bg-gradient-to-r ${barColor}`}
                    style={{ width: `${Math.min(ratio, 150) / 1.5}%` }}
                  />
                </div>
                <div className="flex items-center justify-between mt-1.5">
                  <span className="text-[10px] text-surface-600">CREP Locked: {formatUSD(r.total_crep_locked)}</span>
                  <span className="text-[10px] text-surface-600">NAV: ${r.current_nav.toFixed(4)}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── Rebalance History ──────────────────────────────────────────

function RebalanceHistory({ rebalances }: { rebalances: Rebalance[] }) {
  return (
    <div className="liquid-glass p-5">
      <h3 className="font-display font-semibold text-surface-900 text-sm mb-4">Recent Rebalances</h3>
      {rebalances.length === 0 ? (
        <div className="text-surface-600 text-xs">No rebalances yet</div>
      ) : (
        <div className="space-y-2">
          {rebalances.map((r, i) => (
            <div
              key={r.id}
              className="liquid-row p-3 rounded-xl flex items-center gap-3 stagger-in"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(200, 230, 0, 0.06)', border: '1px solid rgba(200, 230, 0, 0.1)' }}>
                <ArrowUpRight className="w-3.5 h-3.5" style={{ color: '#4a6600' }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-surface-900 font-medium truncate">
                  {r.from_venue} <span className="text-surface-600 mx-1">&rarr;</span> {r.to_venue}
                </div>
                <div className="text-[10px] text-surface-600 mt-0.5">{r.reason}</div>
              </div>
              <div className="text-right flex-shrink-0">
                <div className="text-xs font-mono" style={{ color: '#4a6600' }}>{formatUSD(r.amount_usd)}</div>
                <div className="text-[10px] text-surface-600">{timeAgo(r.executed_at)}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Activity Feed ──────────────────────────────────────────────

function ActivityFeed({ activities }: { activities: AgentActivity[] }) {
  const [filter, setFilter] = useState<string>('all');

  const eventTypes = ['all', ...new Set(activities.map(a => a.event_type))];
  const filtered = filter === 'all' ? activities : activities.filter(a => a.event_type === filter);

  return (
    <div className="liquid-glass p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-semibold text-surface-900 text-sm">Live Agent Feed</h3>
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {eventTypes.slice(0, 5).map(t => (
            <button
              key={t}
              onClick={() => setFilter(t)}
              className={`filter-pill ${filter === t ? 'filter-pill-active' : ''}`}
            >
              {t === 'all' ? 'All' : t.replace(/_/g, ' ')}
            </button>
          ))}
        </div>
      </div>
      <div className="space-y-1.5 max-h-[300px] overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="text-surface-600 text-xs py-4 text-center">No activity recorded</div>
        ) : (
          filtered.map((a, i) => (
            <div
              key={a.id}
              className="liquid-row px-3 py-2.5 rounded-lg flex items-start gap-3 stagger-in"
              style={{ animationDelay: `${i * 40}ms` }}
            >
              <div className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ backgroundColor: '#4a6600', boxShadow: '0 0 6px rgba(200, 230, 0, 0.5)' }} />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-surface-800 leading-relaxed">{a.message}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="liquid-pill text-[10px]">{a.event_type}</span>
                  <span className="text-[10px] text-surface-600">{timeAgo(a.created_at)}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// ─── Price History Section ─────────────────────────────────────

function PriceHistorySection({ feeds }: { feeds: OracleFeed[] }) {
  const [selectedSymbol, setSelectedSymbol] = useState<string | null>(null);
  const [timeframe, setTimeframe] = useState<Timeframe>('1D');
  const [chartData, setChartData] = useState<{ time: string; value: number }[]>([]);
  const [loadingChart, setLoadingChart] = useState(false);

  const hours = timeframe === '1H' ? 1 : timeframe === '4H' ? 4 : timeframe === '1D' ? 24 : timeframe === '1W' ? 168 : timeframe === '1M' ? 720 : 2160;

  useEffect(() => {
    if (!selectedSymbol) return;
    let cancelled = false;
    setLoadingChart(true);
    fetchPriceHistory(selectedSymbol, hours)
      .then(data => {
        if (cancelled) return;
        setChartData(data.map(d => ({ time: d.recorded_at, value: d.price_usd })));
      })
      .catch(() => {})
      .finally(() => { if (!cancelled) setLoadingChart(false); });
    return () => { cancelled = true; };
  }, [selectedSymbol, hours]);

  if (feeds.length === 0) return null;

  return (
    <div className="liquid-glass p-5">
      <div className="flex items-center gap-2.5 mb-4">
        <BarChart3 className="w-4 h-4" style={{ color: '#4a6600' }} />
        <h3 className="font-display font-semibold text-surface-900 text-sm">Price History</h3>
        <span className="text-[10px] text-surface-600">Click a feed to view chart</span>
      </div>

      {/* Feed selector pills */}
      <div className="flex flex-wrap gap-1.5 mb-4">
        {feeds.map(f => (
          <button
            key={f.id}
            onClick={() => setSelectedSymbol(selectedSymbol === f.symbol ? null : f.symbol)}
            className={`px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-medium transition-all ${
              selectedSymbol === f.symbol ? 'text-[#3a5500]' : 'text-surface-600 hover:text-surface-900'
            }`}
            style={selectedSymbol === f.symbol ? { background: 'rgba(200,230,0,0.2)', border: '1px solid rgba(200,230,0,0.3)' } : { background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)' }}
          >
            {f.symbol}
          </button>
        ))}
      </div>

      {/* Chart display */}
      {selectedSymbol && (
        <ChartPanel
          title={`s${selectedSymbol}`}
          subtitle={feeds.find(f => f.symbol === selectedSymbol)?.name}
          timeframe={timeframe}
          onTimeframeChange={setTimeframe}
          lastUpdated={feeds.find(f => f.symbol === selectedSymbol)?.last_updated}
        >
          {loadingChart || chartData.length === 0 ? (
            <div className="w-full h-full flex items-center justify-center">
              <p className="text-xs text-surface-600">
                {loadingChart ? 'Loading chart data...' : 'No historical data yet. Data accumulates every 2 minutes.'}
              </p>
            </div>
          ) : (
            <PriceChart data={chartData} />
          )}
        </ChartPanel>
      )}
    </div>
  );
}
