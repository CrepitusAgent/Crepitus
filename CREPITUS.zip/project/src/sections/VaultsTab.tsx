import { useCallback, useState } from 'react';
import { Vault, Wallet, ArrowUpRight, ArrowDownLeft, X, Check, Loader2 } from 'lucide-react';
import { usePolling } from '../hooks/usePolling';
import { useWallet } from '../hooks/useWallet';
import {
  fetchVaults, fetchUserDeposits, insertUserDeposit,
  type Vault as VaultType, type UserDeposit
} from '../lib/api';
import { formatUSD, formatPercent, timeAgo } from '../lib/utils';

export function VaultsTab() {
  const { connected, address, connect } = useWallet();
  const vaultFetcher = useCallback(() => fetchVaults(), []);
  const { data: vaults } = usePolling(vaultFetcher, 20000);

  const depositFetcher = useCallback(
    () => (address ? fetchUserDeposits(address) : Promise.resolve([])),
    [address]
  );
  const { data: deposits, refetch: refetchDeposits } = usePolling(depositFetcher, 10000);

  const [modalOpen, setModalOpen] = useState(false);
  const [modalVault, setModalVault] = useState<VaultType | null>(null);
  const [modalAction, setModalAction] = useState<'deposit' | 'withdraw'>('deposit');

  const openModal = (vault: VaultType, action: 'deposit' | 'withdraw') => {
    if (!connected) { connect(); return; }
    setModalVault(vault);
    setModalAction(action);
    setModalOpen(true);
  };

  const typeLabel = (t: string) => {
    switch (t) {
      case 'stablecoin_savings': return 'Savings';
      case 'borrowing': return 'Borrowing';
      case 'tokenized_stocks': return 'Stocks';
      case 'swaps': return 'Swaps';
      default: return t;
    }
  };

  return (
    <div className="space-y-6 specular-sweep">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {vaults?.map((v, i) => (
          <div key={v.id} className="liquid-glass p-5 transition-all duration-300 hover:scale-[1.005] stagger-in" style={{ animationDelay: `${i * 70}ms` }}>
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: 'rgba(200, 230, 0, 0.06)', border: '1px solid rgba(200, 230, 0, 0.12)' }}>
                  <Vault className="w-5 h-5" style={{ color: '#4a6600' }} />
                </div>
                <div>
                  <h4 className="font-display font-semibold text-surface-900 text-sm">{v.name}</h4>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="liquid-pill text-[10px]">{typeLabel(v.type)}</span>
                    <div className="flex items-center gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-700" style={{ boxShadow: '0 0 6px rgba(34, 197, 94, 0.5)' }} />
                      <span className="text-[10px] text-emerald-700">Active</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-lg font-mono font-bold" style={{ color: '#4a6600' }}>{formatPercent(v.apy)}</div>
                <div className="text-[10px] uppercase tracking-wider text-surface-600">APY</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="liquid-cell p-3">
                <div className="text-[10px] uppercase tracking-wider text-surface-600 mb-0.5">TVL</div>
                <div className="text-sm font-mono font-semibold text-surface-900">{formatUSD(v.tvl_usd)}</div>
              </div>
              <div className="liquid-cell p-3">
                <div className="text-[10px] uppercase tracking-wider text-surface-600 mb-1">Utilization</div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 liquid-progress">
                    <div className="liquid-progress-fill" style={{ width: `${v.utilization}%` }} />
                  </div>
                  <span className="text-xs font-mono text-surface-300">{v.utilization.toFixed(0)}%</span>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <button onClick={() => openModal(v, 'deposit')} className="liquid-btn-primary flex-1 text-xs py-2.5">
                <ArrowDownLeft className="w-3.5 h-3.5 mr-1.5" />
                Deposit
              </button>
              <button onClick={() => openModal(v, 'withdraw')} className="liquid-btn flex-1 text-xs py-2.5">
                <ArrowUpRight className="w-3.5 h-3.5 mr-1.5" />
                Withdraw
              </button>
            </div>
          </div>
        ))}
        {!vaults && Array.from({ length: 4 }).map((_, i) => <div key={i} className="shimmer h-56 rounded-2xl" />)}
      </div>

      {connected && deposits && deposits.length > 0 && (
        <div className="liquid-glass p-5">
          <h3 className="font-display font-semibold text-surface-900 text-sm mb-4">Your Positions</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-surface-600 uppercase tracking-wider">
                  <th className="text-left pb-3 font-medium">Action</th>
                  <th className="text-right pb-3 font-medium">Amount</th>
                  <th className="text-right pb-3 font-medium">When</th>
                </tr>
              </thead>
              <tbody>
                {deposits.map(d => (
                  <tr key={d.id} className="liquid-row">
                    <td className="py-2.5">
                      <span className={`liquid-pill${d.action === 'deposit' ? '-lime' : ''} text-[10px] gap-1`}>
                        {d.action === 'deposit' ? <ArrowDownLeft className="w-3 h-3" /> : <ArrowUpRight className="w-3 h-3" />}
                        {d.action}
                      </span>
                    </td>
                    <td className="py-2.5 text-right font-mono text-surface-900">{formatUSD(d.amount_usd)}</td>
                    <td className="py-2.5 text-right text-surface-600">{timeAgo(d.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {!connected && (
        <div className="liquid-glass p-8 text-center">
          <Wallet className="w-8 h-8 text-surface-600 mx-auto mb-3" />
          <p className="text-sm text-surface-600 mb-4">Connect your wallet to deposit or withdraw</p>
          <button onClick={connect} className="liquid-btn text-xs">
            <Wallet className="w-3.5 h-3.5 mr-1.5" />
            Connect Wallet
          </button>
        </div>
      )}

      {modalOpen && modalVault && (
        <DepositModal
          vault={modalVault}
          action={modalAction}
          walletAddress={address!}
          onClose={() => setModalOpen(false)}
          onSuccess={() => { setModalOpen(false); refetchDeposits(); }}
        />
      )}
    </div>
  );
}

function DepositModal({
  vault, action, walletAddress, onClose, onSuccess
}: {
  vault: VaultType;
  action: 'deposit' | 'withdraw';
  walletAddress: string;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    const num = parseFloat(amount);
    if (!num || num <= 0) { setError('Enter a valid amount'); return; }
    setLoading(true);
    setError('');
    try {
      await insertUserDeposit(walletAddress, vault.id, num, action);
      setSuccess(true);
      setTimeout(onSuccess, 1500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Transaction failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-panel" onClick={e => e.stopPropagation()}>
        {success ? (
          <div className="text-center py-8">
            <div className="w-14 h-14 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ background: 'rgba(34, 197, 94, 0.1)', border: '1px solid rgba(34, 197, 94, 0.2)' }}>
              <Check className="w-7 h-7 text-emerald-700" />
            </div>
            <h3 className="font-display font-semibold text-surface-900 text-lg mb-1">
              {action === 'deposit' ? 'Deposited' : 'Withdrawn'} Successfully
            </h3>
            <p className="text-sm text-surface-600">{formatUSD(parseFloat(amount))} {action === 'deposit' ? 'into' : 'from'} {vault.name}</p>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display font-semibold text-surface-900">
                {action === 'deposit' ? 'Deposit to' : 'Withdraw from'} Vault
              </h3>
              <button onClick={onClose} className="text-surface-600 hover:text-surface-900 transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="liquid-cell p-4 mb-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium text-surface-900">{vault.name}</div>
                  <div className="text-xs text-surface-600 mt-0.5">Current APY: {formatPercent(vault.apy)}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-mono font-bold" style={{ color: '#4a6600' }}>{formatUSD(vault.tvl_usd)}</div>
                  <div className="text-[10px] text-surface-600">TVL</div>
                </div>
              </div>
            </div>

            <div className="mb-5">
              <label className="text-xs text-surface-600 uppercase tracking-wider mb-2 block">Amount (USD)</label>
              <div className="relative">
                <input
                  type="number"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-4 py-3 rounded-xl font-mono text-surface-900 text-lg placeholder-surface-600 focus:outline-none focus:ring-1 focus:ring-lime-500/30 transition-all"
                  style={{ background: 'rgba(255, 255, 255, 0.03)', border: '1px solid rgba(255, 255, 255, 0.08)' }}
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-surface-600">USD</span>
              </div>
            </div>

            {error && <div className="text-xs text-red-400 mb-4">{error}</div>}

            <button
              onClick={handleSubmit}
              disabled={loading}
              className="liquid-btn-primary w-full py-3 text-sm"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : action === 'deposit' ? (
                <ArrowDownLeft className="w-4 h-4 mr-2" />
              ) : (
                <ArrowUpRight className="w-4 h-4 mr-2" />
              )}
              {loading ? 'Processing...' : `Confirm ${action === 'deposit' ? 'Deposit' : 'Withdrawal'}`}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
