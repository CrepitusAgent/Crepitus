import { useState, useEffect, lazy, Suspense } from 'react';
import { LandingPage } from './sections/LandingPage';
import { Sidebar, MobileNav, type TabId } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ToastProvider } from './components/Toast';
import { CommandPalette } from './components/CommandPalette';
import { OverviewTab } from './sections/OverviewTab';
import { VenuesTab } from './sections/VenuesTab';
import { VaultsTab } from './sections/VaultsTab';
import { AssetsTab } from './sections/AssetsTab';
import { ActivityTab } from './sections/ActivityTab';
import { PositionsTab } from './sections/PositionsTab';
import { RiskTab } from './sections/RiskTab';
import { AgentPanel } from './components/AgentPanel';
import { AlertsPanel } from './components/AlertsPanel';

function App() {
  const [showDashboard, setShowDashboard] = useState(false);
  const [activeTab, setActiveTab] = useState<TabId>('overview');
  const [chatOpen, setChatOpen] = useState(false);
  const [alertsOpen, setAlertsOpen] = useState(false);
  const [cmdOpen, setCmdOpen] = useState(false);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCmdOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const renderTab = () => {
    switch (activeTab) {
      case 'overview': return <OverviewTab />;
      case 'venues': return <VenuesTab />;
      case 'vaults': return <VaultsTab />;
      case 'positions': return <PositionsTab />;
      case 'assets': return <AssetsTab />;
      case 'activity': return <ActivityTab />;
      case 'risk': return <RiskTab />;
    }
  };

  if (!showDashboard) {
    return <LandingPage onEnter={() => setShowDashboard(true)} />;
  }

  return (
    <ToastProvider>
      <div className="h-full flex flex-col overflow-hidden relative" style={{ background: '#8a8a8a' }}>
        {/* Background glows */}
        <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
          <div className="absolute w-[800px] h-[800px] rounded-full" style={{ top: '-15%', left: '-10%', background: 'radial-gradient(circle, rgba(200, 230, 0, 0.15) 0%, rgba(200, 230, 0, 0.05) 40%, transparent 70%)', filter: 'blur(80px)' }} />
          <div className="absolute w-[600px] h-[600px] rounded-full" style={{ bottom: '-10%', right: '-8%', background: 'radial-gradient(circle, rgba(200, 230, 0, 0.1) 0%, rgba(154, 184, 0, 0.04) 50%, transparent 70%)', filter: 'blur(60px)' }} />
          <div className="absolute w-[1000px] h-[1000px] rounded-full" style={{ top: '45%', left: '50%', transform: 'translate(-50%, -50%)', background: 'radial-gradient(circle, rgba(200, 230, 0, 0.06) 0%, transparent 50%)', filter: 'blur(120px)' }} />
          <div className="absolute inset-0 noise-overlay" />
        </div>

        <TopBar onOpenChat={() => setChatOpen(true)} onOpenAlerts={() => setAlertsOpen(true)} />
        <div className="flex flex-1 overflow-hidden relative z-10">
          <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
          <main className="flex-1 overflow-y-auto p-4 md:p-6 pb-20 md:pb-6 dot-matrix-bg">
            <div className="max-w-[1400px] mx-auto">
              <ErrorBoundary fallbackTitle={`Error loading ${activeTab}`}>
                {renderTab()}
              </ErrorBoundary>
            </div>
          </main>
          {chatOpen && (
            <AgentPanel isOpen={chatOpen} onClose={() => setChatOpen(false)} activeTab={activeTab} />
          )}
        </div>
        <MobileNav activeTab={activeTab} onTabChange={setActiveTab} />
        <CommandPalette open={cmdOpen} onClose={() => setCmdOpen(false)} onNavigate={setActiveTab} onOpenChat={() => setChatOpen(true)} />
        <AlertsPanel open={alertsOpen} onClose={() => setAlertsOpen(false)} />
      </div>
    </ToastProvider>
  );
}

export default App;
