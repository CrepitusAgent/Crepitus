import { Component, type ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallbackTitle?: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, error: null };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="liquid-glass p-6 text-center">
          <AlertTriangle className="w-8 h-8 text-amber-600 mx-auto mb-3" />
          <h3 className="font-display font-semibold text-surface-900 text-sm mb-1">
            {this.props.fallbackTitle || 'Something went wrong'}
          </h3>
          <p className="text-xs text-surface-600 mb-4">
            This section encountered an error.
          </p>
          <button onClick={this.handleRetry} className="liquid-btn text-xs">
            <RefreshCw className="w-3.5 h-3.5 mr-1.5" />
            Retry
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
