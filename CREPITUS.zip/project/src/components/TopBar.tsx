import { useEffect, useState, useCallback, useRef } from 'react';
import { Wallet, LogOut, Zap, MessageCircle, Bell, Command } from 'lucide-react';
import { useWallet } from '../hooks/useWallet';
import { fetchAgentState } from '../lib/api';
import { truncateAddress, formatCountdown } from '../lib/utils';

interface TopBarProps {
  onOpenChat?: () => void;
  onOpenAlerts?: () => void;
}

export function TopBar({ onOpenChat, onOpenAlerts }: TopBarProps) {
  const { address, connected, connecting, connect, disconnect, hasProvider } = useWallet();
  const [countdown, setCountdown] = useState('--:--:--');
  const [venue, setVenue] = useState('...');
  const nextRebalanceRef = useRef<string | null>(null);

  const loadState = useCallback(async () => {
    try {
      const s = await fetchAgentState();
      if (s) {
        setVenue(s.current_best_venue);
        nextRebalanceRef.current = s.next_rebalance_at;
      }
    } catch {}
  }, []);

  useEffect(() => {
    loadState();
    const i = setInterval(loadState, 10000);
    return () => clearInterval(i);
  }, [loadState]);

  useEffect(() => {
    const tick = () => {
      if (nextRebalanceRef.current) {
        setCountdown(formatCountdown(nextRebalanceRef.current));
      }
    };
    tick();
    const i = setInterval(tick, 1000);
    return () => clearInterval(i);
  }, []);

  return (
    <header className="frosted-topbar h-14 flex items-center px-4 md:px-6 gap-4 z-40 relative">
      <div className="absolute bottom-0 left-0 right-0 h-[1.5px]" style={{ background: 'linear-gradient(90deg, transparent, rgba(200, 230, 0, 0.5), transparent)' }} />
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'rgba(200, 230, 0, 0.2)', border: '1.5px solid rgba(200, 230, 0, 0.35)', boxShadow: '0 0 15px rgba(200, 230, 0, 0.15)' }}>
          <Zap className="w-4 h-4" style={{ color: '#5a7a00' }} />
        </div>
        <span className="font-display font-bold text-surface-900 text-sm hidden sm:block">Crepitus</span>
      </div>

      <div className="hidden sm:flex items-center gap-4 ml-4 pl-4 border-l border-white/[0.12]">
        <div className="flex items-center gap-2">
          <div className="agent-active-ring" />
          <span className="text-xs font-medium" style={{ color: '#4a6600' }}>Agent Active</span>
        </div>
        <div className="w-px h-4 bg-white/[0.12]" />
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-surface-600">Next Cycle:</span>
          <span className="text-xs font-mono font-semibold text-surface-900 tabular-nums">{countdown}</span>
        </div>
        <div className="w-px h-4 bg-white/[0.12]" />
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-surface-600">Routing to:</span>
          <span className="text-xs font-medium truncate max-w-[140px]" style={{ color: '#4a6600' }}>{venue}</span>
        </div>
      </div>

      <div className="flex items-center gap-2 ml-auto">
        {/* Cmd+K hint */}
        <button
          className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs text-surface-600 transition-all hover:text-surface-900"
          style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)' }}
          aria-label="Open command palette (Cmd+K)"
        >
          <Command className="w-3 h-3" />
          <span className="font-mono text-[10px]">K</span>
        </button>

        {/* AI Chat */}
        {onOpenChat && (
          <button
            onClick={onOpenChat}
            className="relative p-2 rounded-xl text-surface-600 hover:text-surface-900 transition-all"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)' }}
            aria-label="Open AI assistant"
          >
            <MessageCircle className="w-4 h-4" />
            <div className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full" style={{ background: '#c8e600', boxShadow: '0 0 6px rgba(200,230,0,0.6)' }} />
          </button>
        )}

        {/* Alerts */}
        {onOpenAlerts && (
          <button
            onClick={onOpenAlerts}
            className="p-2 rounded-xl text-surface-600 hover:text-surface-900 transition-all"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)' }}
            aria-label="Open alerts"
          >
            <Bell className="w-4 h-4" />
          </button>
        )}

        {/* Wallet */}
        {connected ? (
          <button
            onClick={disconnect}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-mono transition-all duration-200 hover:scale-[1.02]"
            style={{ background: 'rgba(200, 230, 0, 0.15)', border: '1.5px solid rgba(200, 230, 0, 0.3)', color: '#3a5500' }}
          >
            <Wallet className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{truncateAddress(address!)}</span>
            <LogOut className="w-3 h-3 opacity-50" />
          </button>
        ) : (
          <button
            onClick={connect}
            disabled={connecting}
            className="liquid-btn text-xs py-2 px-4"
          >
            <Wallet className="w-3.5 h-3.5 mr-1.5" />
            {!hasProvider ? 'Install MetaMask' : connecting ? 'Connecting...' : 'Connect Wallet'}
          </button>
        )}
      </div>
    </header>
  );
}
