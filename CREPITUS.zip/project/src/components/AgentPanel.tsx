import { useState, useRef, useEffect, useCallback } from 'react';
import { X, Send, Bot, User, Sparkles, Loader2 } from 'lucide-react';
import { sendChatMessage, type ChatMessage } from '../lib/api';
import type { TabId } from './Sidebar';

interface AgentPanelProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: TabId;
}

const SUGGESTED: Record<string, string[]> = {
  overview: ['Summarize the market conditions', 'What is protocol health?', 'Explain yield velocity'],
  venues: ['Compare the top venues', 'Which venue is safest?', 'Explain composite scoring'],
  vaults: ['What is the total TVL?', 'Explain vault utilization', 'Which vault has best APY?'],
  positions: ['Explain reserve ratios', 'How does minting work?', 'What are the risks?'],
  assets: ['List synthetic equities', 'How does oracle backing work?', 'Compare asset performance'],
  activity: ['Summarize recent activity', 'When was the last rebalance?', 'Explain the scoring cycle'],
  risk: ['What are the main risks?', 'Explain reserve adequacy', 'Is there concentration risk?'],
};

export function AgentPanel({ isOpen, onClose, activeTab }: AgentPanelProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) setTimeout(() => inputRef.current?.focus(), 100);
  }, [isOpen]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = useCallback(async (text?: string) => {
    const msg = text || input.trim();
    if (!msg || loading) return;

    const userMsg: ChatMessage = { role: 'user', content: msg, timestamp: new Date().toISOString() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);
    setError(null);

    try {
      const result = await sendChatMessage(msg, messages, { activeTab, timestamp: new Date().toISOString() });
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: result.reply,
        timestamp: new Date().toISOString(),
        sources: result.sources,
      }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to get response');
    } finally {
      setLoading(false);
    }
  }, [input, loading, messages, activeTab]);

  if (!isOpen) return null;

  const suggestions = SUGGESTED[activeTab] || SUGGESTED.overview;

  return (
    <aside className="w-[380px] flex-shrink-0 flex flex-col border-l border-white/[0.12] h-full overflow-hidden z-30" style={{ background: 'rgba(80, 80, 80, 0.4)', backdropFilter: 'blur(40px)' }}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/[0.08]">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: 'rgba(200,230,0,0.15)', border: '1px solid rgba(200,230,0,0.25)' }}>
            <Bot className="w-4 h-4" style={{ color: '#4a6600' }} />
          </div>
          <div>
            <span className="text-xs font-display font-semibold text-surface-900">Crepitus Agent</span>
            <div className="flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" style={{ boxShadow: '0 0 4px rgba(34,197,94,0.4)' }} />
              <span className="text-[10px] text-surface-600">Online</span>
            </div>
          </div>
        </div>
        <button onClick={onClose} className="p-1.5 rounded-lg text-surface-600 hover:text-surface-900 transition-colors" style={{ background: 'rgba(255,255,255,0.06)' }} aria-label="Close chat">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.length === 0 && (
          <div className="space-y-4">
            <div className="text-center py-6">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-3" style={{ background: 'rgba(200,230,0,0.1)', border: '1px solid rgba(200,230,0,0.2)' }}>
                <Sparkles className="w-6 h-6" style={{ color: '#4a6600' }} />
              </div>
              <p className="text-sm font-display font-semibold text-surface-900 mb-1">Financial Intelligence</p>
              <p className="text-[11px] text-surface-600 max-w-[260px] mx-auto leading-relaxed">
                Ask about market conditions, risk metrics, or any protocol concept.
              </p>
            </div>
            <div className="space-y-1.5">
              <span className="text-[10px] uppercase tracking-wider text-surface-600 font-medium">Suggested</span>
              {suggestions.map(prompt => (
                <button
                  key={prompt}
                  onClick={() => handleSend(prompt)}
                  className="w-full text-left px-3 py-2.5 rounded-xl text-xs text-surface-600 hover:text-surface-900 transition-all"
                  style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg, i) => (
          <div key={i} className={`flex gap-2.5 ${msg.role === 'user' ? 'justify-end' : ''}`}>
            {msg.role === 'assistant' && (
              <div className="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5" style={{ background: 'rgba(200,230,0,0.1)', border: '1px solid rgba(200,230,0,0.15)' }}>
                <Bot className="w-3.5 h-3.5" style={{ color: '#4a6600' }} />
              </div>
            )}
            <div className={`max-w-[85%] px-3 py-2.5 rounded-xl text-xs leading-relaxed ${
              msg.role === 'user' ? 'text-white' : 'text-surface-800'
            }`} style={msg.role === 'user' ? { background: 'rgba(200,230,0,0.2)', border: '1px solid rgba(200,230,0,0.3)' } : { background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)' }}>
              <p className="whitespace-pre-wrap">{msg.content}</p>
              {msg.sources && msg.sources.length > 0 && (
                <div className="mt-2 pt-2 border-t border-white/[0.06]">
                  <span className="text-[9px] uppercase tracking-wider text-surface-600">Sources: {msg.sources.join(', ')}</span>
                </div>
              )}
            </div>
            {msg.role === 'user' && (
              <div className="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 bg-white/[0.08] border border-white/[0.1]">
                <User className="w-3.5 h-3.5 text-surface-600" />
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex gap-2.5">
            <div className="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(200,230,0,0.1)', border: '1px solid rgba(200,230,0,0.15)' }}>
              <Bot className="w-3.5 h-3.5" style={{ color: '#4a6600' }} />
            </div>
            <div className="px-3 py-2.5 rounded-xl" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)' }}>
              <Loader2 className="w-3.5 h-3.5 animate-spin text-surface-600" />
            </div>
          </div>
        )}

        {error && (
          <div className="px-3 py-2 rounded-xl bg-red-500/10 border border-red-500/20">
            <span className="text-xs text-red-400">{error}</span>
          </div>
        )}

        <div ref={endRef} />
      </div>

      {/* Input */}
      <div className="px-4 py-3 border-t border-white/[0.08]">
        <div className="flex items-center gap-2 rounded-xl px-3 py-2" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
          <input
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
            placeholder="Ask about your portfolio..."
            className="flex-1 bg-transparent text-xs text-surface-900 placeholder-surface-600 outline-none"
          />
          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || loading}
            className="p-1.5 rounded-lg transition-all disabled:opacity-30"
            style={{ color: '#4a6600' }}
            aria-label="Send message"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <p className="text-[9px] text-surface-600 mt-1.5 text-center">
          Responses generated from live protocol data. Not financial advice.
        </p>
      </div>
    </aside>
  );
}
