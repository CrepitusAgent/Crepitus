import { Activity, Trophy, Vault, Layers, ScrollText, BarChart3, Shield, Zap } from 'lucide-react';

export type TabId = 'overview' | 'venues' | 'vaults' | 'positions' | 'assets' | 'activity' | 'risk';

interface SidebarProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
}

const tabs: { id: TabId; icon: typeof Activity; label: string }[] = [
  { id: 'overview', icon: Activity, label: 'Overview' },
  { id: 'venues', icon: Trophy, label: 'Venues' },
  { id: 'vaults', icon: Vault, label: 'Vaults' },
  { id: 'positions', icon: BarChart3, label: 'Positions' },
  { id: 'assets', icon: Layers, label: 'Assets' },
  { id: 'risk', icon: Shield, label: 'Risk' },
  { id: 'activity', icon: ScrollText, label: 'Activity' },
];

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  return (
    <aside className="hidden md:flex frosted-sidebar w-[72px] flex-col items-center py-6 gap-2 z-40">
      <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ background: 'rgba(200, 230, 0, 0.2)', border: '1.5px solid rgba(200, 230, 0, 0.35)', boxShadow: '0 0 20px rgba(200, 230, 0, 0.12)' }}>
        <Zap className="w-5 h-5" style={{ color: '#5a7a00' }} />
      </div>
      <div className="w-8 h-px bg-white/[0.12] mb-2" />

      <div className="flex flex-col items-center gap-1 flex-1">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`nav-tab group relative ${activeTab === tab.id ? 'nav-tab-active' : ''}`}
            title={tab.label}
            aria-label={`Navigate to ${tab.label}`}
          >
            <tab.icon className="w-5 h-5" />
            <span className="absolute left-full ml-3 px-2.5 py-1 rounded-lg text-xs font-medium bg-surface-800 text-white border border-white/10 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
              {tab.label}
            </span>
          </button>
        ))}
      </div>
    </aside>
  );
}

export function MobileNav({ activeTab, onTabChange }: SidebarProps) {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 frosted-topbar border-t border-b-0 border-white/[0.1] px-2 py-2" role="tablist">
      <div className="flex items-center justify-around">
        {tabs.slice(0, 6).map(tab => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-xl transition-all ${
              activeTab === tab.id ? 'nav-tab-active' : ''
            }`}
            style={activeTab !== tab.id ? { color: '#4a4a4a' } : {}}
            role="tab"
            aria-selected={activeTab === tab.id}
            aria-label={tab.label}
          >
            <tab.icon className="w-4 h-4" />
            <span className="text-[9px] font-medium">{tab.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
