import { useState, type ReactNode } from 'react';
import { Maximize2, Minimize2, Clock } from 'lucide-react';

export type Timeframe = '1H' | '4H' | '1D' | '1W' | '1M' | 'ALL';

interface ChartPanelProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
  timeframe?: Timeframe;
  onTimeframeChange?: (tf: Timeframe) => void;
  lastUpdated?: string | null;
  className?: string;
}

const timeframes: Timeframe[] = ['1H', '4H', '1D', '1W', '1M', 'ALL'];

export function ChartPanel({
  title,
  subtitle,
  children,
  timeframe,
  onTimeframeChange,
  lastUpdated,
  className = '',
}: ChartPanelProps) {
  const [fullscreen, setFullscreen] = useState(false);

  const content = (
    <div className={`liquid-glass p-5 ${className}`}>
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div>
          <h3 className="font-display font-semibold text-surface-900 text-sm">{title}</h3>
          {subtitle && <p className="text-[10px] text-surface-600 mt-0.5">{subtitle}</p>}
        </div>
        <div className="flex items-center gap-2">
          {onTimeframeChange && (
            <div className="flex items-center gap-0.5 p-0.5 rounded-lg" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)' }}>
              {timeframes.map(tf => (
                <button
                  key={tf}
                  onClick={() => onTimeframeChange(tf)}
                  className={`px-2 py-1 rounded-md text-[10px] font-mono font-medium transition-all ${
                    timeframe === tf ? 'text-[#3a5500]' : 'text-surface-600 hover:text-surface-900'
                  }`}
                  style={timeframe === tf ? { background: 'rgba(200,230,0,0.2)', border: '1px solid rgba(200,230,0,0.3)' } : {}}
                >
                  {tf}
                </button>
              ))}
            </div>
          )}
          {lastUpdated && (
            <div className="flex items-center gap-1 text-[10px] text-surface-600">
              <Clock className="w-3 h-3" />
              <span className="font-mono">{formatRelative(lastUpdated)}</span>
            </div>
          )}
          <button
            onClick={() => setFullscreen(!fullscreen)}
            className="p-1.5 rounded-lg text-surface-600 hover:text-surface-900 transition-colors"
            style={{ background: 'rgba(255,255,255,0.06)' }}
            aria-label={fullscreen ? 'Exit fullscreen' : 'Fullscreen'}
          >
            {fullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
      <div className={fullscreen ? 'h-[calc(100vh-200px)]' : 'h-[280px]'}>
        {children}
      </div>
    </div>
  );

  if (fullscreen) {
    return (
      <div className="fixed inset-0 z-50 p-6 flex items-center justify-center" style={{ background: 'rgba(80,80,80,0.9)', backdropFilter: 'blur(12px)' }}>
        <div className="w-full max-w-6xl">{content}</div>
      </div>
    );
  }

  return content;
}

function formatRelative(dateStr: string): string {
  const diff = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (diff < 60) return `${diff}s`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m`;
  return `${Math.floor(diff / 3600)}h`;
}
