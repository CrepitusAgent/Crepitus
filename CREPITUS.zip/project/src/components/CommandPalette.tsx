import { useState, useEffect, useRef } from 'react';
import { Search, Activity, Trophy, Vault, BarChart3, Layers, ScrollText, Shield, MessageCircle } from 'lucide-react';
import type { TabId } from './Sidebar';

interface CommandPaletteProps {
  open: boolean;
  onClose: () => void;
  onNavigate: (tab: TabId) => void;
  onOpenChat: () => void;
}

export function CommandPalette({ open, onClose, onNavigate, onOpenChat }: CommandPaletteProps) {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) { setQuery(''); setTimeout(() => inputRef.current?.focus(), 50); }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', h);
    return () => document.removeEventListener('keydown', h);
  }, [open, onClose]);

  const commands = [
    { id: 'overview', label: 'Go to Overview', icon: Activity, action: () => { onNavigate('overview'); onClose(); } },
    { id: 'venues', label: 'Go to Venues', icon: Trophy, action: () => { onNavigate('venues'); onClose(); } },
    { id: 'vaults', label: 'Go to Vaults', icon: Vault, action: () => { onNavigate('vaults'); onClose(); } },
    { id: 'positions', label: 'Go to Positions', icon: BarChart3, action: () => { onNavigate('positions'); onClose(); } },
    { id: 'assets', label: 'Go to Assets', icon: Layers, action: () => { onNavigate('assets'); onClose(); } },
    { id: 'risk', label: 'Go to Risk', icon: Shield, action: () => { onNavigate('risk'); onClose(); } },
    { id: 'activity', label: 'Go to Activity', icon: ScrollText, action: () => { onNavigate('activity'); onClose(); } },
    { id: 'chat', label: 'Open AI Agent', icon: MessageCircle, action: () => { onOpenChat(); onClose(); } },
  ];

  const filtered = query ? commands.filter(c => c.label.toLowerCase().includes(query.toLowerCase())) : commands;

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[90] flex items-start justify-center pt-[20vh]" onClick={onClose}>
      <div className="absolute inset-0" style={{ background: 'rgba(80,80,80,0.5)', backdropFilter: 'blur(4px)' }} />
      <div
        className="relative w-full max-w-lg rounded-2xl overflow-hidden"
        onClick={e => e.stopPropagation()}
        style={{ background: 'rgba(50,50,50,0.95)', backdropFilter: 'blur(30px)', border: '1px solid rgba(255,255,255,0.15)', boxShadow: '0 24px 80px rgba(0,0,0,0.5)', animation: 'slide-up 0.2s ease-out' }}
      >
        <div className="flex items-center gap-3 px-4 py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <Search className="w-4 h-4 text-gray-400" />
          <input ref={inputRef} value={query} onChange={e => setQuery(e.target.value)} placeholder="Type a command..." className="flex-1 bg-transparent text-sm text-white placeholder-gray-500 outline-none" />
          <kbd className="text-[10px] text-gray-500 px-1.5 py-0.5 rounded" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>ESC</kbd>
        </div>
        <div className="max-h-[300px] overflow-y-auto p-2">
          {filtered.map(cmd => (
            <button key={cmd.id} onClick={cmd.action} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-colors hover:bg-white/5">
              <cmd.icon className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-200">{cmd.label}</span>
            </button>
          ))}
          {filtered.length === 0 && <div className="text-center py-6 text-sm text-gray-500">No results</div>}
        </div>
      </div>
    </div>
  );
}
