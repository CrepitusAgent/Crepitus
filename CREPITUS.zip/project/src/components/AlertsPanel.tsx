import { useState, useEffect, useCallback } from 'react';
import { Bell, Plus, Trash2, X, TrendingDown, TrendingUp, Shield, Mail, Check, Loader2 } from 'lucide-react';
import { useWallet } from '../hooks/useWallet';
import { fetchAlerts, createAlert, deleteAlert, fetchOracleFeeds, subscribeEmail, type Alert, type OracleFeed } from '../lib/api';

interface AlertsPanelProps {
  open: boolean;
  onClose: () => void;
}

export function AlertsPanel({ open, onClose }: AlertsPanelProps) {
  const { address, connected } = useWallet();
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [feeds, setFeeds] = useState<OracleFeed[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [showEmail, setShowEmail] = useState(false);
  const [loading, setLoading] = useState(false);

  const loadData = useCallback(async () => {
    if (!connected || !address) return;
    try {
      const [a, f] = await Promise.all([fetchAlerts(address), fetchOracleFeeds()]);
      setAlerts(a);
      setFeeds(f);
    } catch {}
  }, [connected, address]);

  useEffect(() => {
    if (open) loadData();
  }, [open, loadData]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0" style={{ background: 'rgba(80,80,80,0.6)', backdropFilter: 'blur(8px)' }} />
      <div className="relative w-full max-w-md mx-4 max-h-[80vh] flex flex-col rounded-2xl overflow-hidden" onClick={e => e.stopPropagation()} style={{ background: 'rgba(60,60,60,0.95)', backdropFilter: 'blur(40px)', border: '1px solid rgba(255,255,255,0.15)', boxShadow: '0 24px 80px rgba(0,0,0,0.5)', animation: 'slide-up 0.3s ease-out' }}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.08]">
          <div className="flex items-center gap-2.5">
            <Bell className="w-4 h-4" style={{ color: '#4a6600' }} />
            <h3 className="font-display font-semibold text-white text-sm">Alerts</h3>
            {alerts.filter(a => a.is_active).length > 0 && (
              <span className="liquid-pill-lime text-[10px]">{alerts.filter(a => a.is_active).length} active</span>
            )}
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-gray-400 hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {!connected ? (
            <div className="text-center py-8">
              <Bell className="w-8 h-8 text-gray-500 mx-auto mb-3" />
              <p className="text-sm text-gray-400">Connect wallet to manage alerts</p>
            </div>
          ) : showCreate ? (
            <CreateAlertForm feeds={feeds} walletAddress={address!} onCreated={() => { setShowCreate(false); loadData(); }} onCancel={() => setShowCreate(false)} />
          ) : showEmail ? (
            <EmailSignupForm walletAddress={address} onDone={() => setShowEmail(false)} />
          ) : (
            <>
              <div className="flex gap-2">
                <button onClick={() => setShowCreate(true)} className="liquid-btn text-xs flex-1">
                  <Plus className="w-3.5 h-3.5 mr-1.5" /> New Alert
                </button>
                <button onClick={() => setShowEmail(true)} className="liquid-btn text-xs flex-1">
                  <Mail className="w-3.5 h-3.5 mr-1.5" /> Email Updates
                </button>
              </div>

              {alerts.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-sm text-gray-400">No alerts configured</p>
                  <p className="text-[11px] text-gray-500 mt-1">Create alerts to get notified of price movements</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {alerts.map(alert => (
                    <AlertRow key={alert.id} alert={alert} onDelete={async () => { await deleteAlert(alert.id); loadData(); }} />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function AlertRow({ alert, onDelete }: { alert: Alert; onDelete: () => void }) {
  const icon = alert.alert_type === 'price_above' ? TrendingUp : alert.alert_type === 'price_below' ? TrendingDown : Shield;
  const Icon = icon;
  return (
    <div className="flex items-center gap-3 p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}>
      <Icon className="w-4 h-4 text-gray-400 flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <div className="text-xs text-white font-medium truncate">{alert.condition}</div>
        <div className="text-[10px] text-gray-500">{alert.asset_symbol || 'Protocol'} -- Threshold: {alert.threshold}</div>
      </div>
      <div className={`w-2 h-2 rounded-full ${alert.is_active ? 'bg-emerald-500' : 'bg-gray-600'}`} />
      <button onClick={onDelete} className="p-1 text-gray-500 hover:text-red-400 transition-colors">
        <Trash2 className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}

function CreateAlertForm({ feeds, walletAddress, onCreated, onCancel }: { feeds: OracleFeed[]; walletAddress: string; onCreated: () => void; onCancel: () => void }) {
  const [alertType, setAlertType] = useState('price_below');
  const [symbol, setSymbol] = useState(feeds[0]?.symbol || '');
  const [threshold, setThreshold] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    const t = parseFloat(threshold);
    if (!t || t <= 0) { setError('Enter a valid threshold'); return; }
    setLoading(true);
    setError('');
    try {
      await createAlert({
        wallet_address: walletAddress,
        alert_type: alertType,
        asset_symbol: symbol || null,
        condition: `${symbol || 'Protocol'} ${alertType.replace(/_/g, ' ')} $${t}`,
        threshold: t,
      });
      onCreated();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <h4 className="text-xs font-semibold text-white">Create Alert</h4>
      <div>
        <label className="text-[10px] text-gray-400 uppercase tracking-wider block mb-1">Type</label>
        <select value={alertType} onChange={e => setAlertType(e.target.value)} className="w-full px-3 py-2 rounded-lg text-xs text-white" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
          <option value="price_below">Price drops below</option>
          <option value="price_above">Price rises above</option>
          <option value="reserve_ratio_below">Reserve ratio below</option>
        </select>
      </div>
      {alertType.startsWith('price') && (
        <div>
          <label className="text-[10px] text-gray-400 uppercase tracking-wider block mb-1">Asset</label>
          <select value={symbol} onChange={e => setSymbol(e.target.value)} className="w-full px-3 py-2 rounded-lg text-xs text-white" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
            {feeds.map(f => <option key={f.id} value={f.symbol}>{f.symbol} - {f.name}</option>)}
          </select>
        </div>
      )}
      <div>
        <label className="text-[10px] text-gray-400 uppercase tracking-wider block mb-1">Threshold</label>
        <input type="number" value={threshold} onChange={e => setThreshold(e.target.value)} placeholder="0.00" className="w-full px-3 py-2 rounded-lg text-xs text-white placeholder-gray-500" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }} />
      </div>
      {error && <p className="text-xs text-red-400">{error}</p>}
      <div className="flex gap-2">
        <button onClick={onCancel} className="flex-1 px-3 py-2 rounded-lg text-xs text-gray-400 hover:text-white transition-colors" style={{ background: 'rgba(255,255,255,0.04)' }}>Cancel</button>
        <button onClick={handleSubmit} disabled={loading} className="liquid-btn-primary flex-1 text-xs py-2">
          {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Create'}
        </button>
      </div>
    </div>
  );
}

function EmailSignupForm({ walletAddress, onDone }: { walletAddress: string | null; onDone: () => void }) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    if (!email || !email.includes('@')) { setError('Enter a valid email'); return; }
    setLoading(true);
    setError('');
    try {
      await subscribeEmail(email, walletAddress || undefined);
      setSuccess(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="text-center py-8">
        <div className="w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center" style={{ background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.2)' }}>
          <Check className="w-6 h-6 text-emerald-500" />
        </div>
        <p className="text-sm text-white font-medium">Subscribed!</p>
        <p className="text-[11px] text-gray-400 mt-1">You'll receive exclusive protocol updates.</p>
        <button onClick={onDone} className="liquid-btn text-xs mt-4">Done</button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h4 className="text-xs font-semibold text-white">Email Notifications</h4>
      <p className="text-[11px] text-gray-400 leading-relaxed">Sign up for exclusive protocol updates, alert notifications, and weekly portfolio summaries.</p>
      <div>
        <label className="text-[10px] text-gray-400 uppercase tracking-wider block mb-1">Email</label>
        <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className="w-full px-3 py-2 rounded-lg text-xs text-white placeholder-gray-500" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }} />
      </div>
      {error && <p className="text-xs text-red-400">{error}</p>}
      <div className="flex gap-2">
        <button onClick={onDone} className="flex-1 px-3 py-2 rounded-lg text-xs text-gray-400 hover:text-white transition-colors" style={{ background: 'rgba(255,255,255,0.04)' }}>Cancel</button>
        <button onClick={handleSubmit} disabled={loading} className="liquid-btn-primary flex-1 text-xs py-2">
          {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <><Mail className="w-3.5 h-3.5 mr-1" /> Subscribe</>}
        </button>
      </div>
    </div>
  );
}
